<?php
class user{
 
    // database connection and table name
    private $conn;
    private $table_name = "lod_users";
 
    // object properties
    public $id;
    public $fullname;
    public $email;
    public $mobile;
    public $user_type;
    public $device_id;
    public $device_type;
	 public $status;
	  public $reg_time;
	   public $update_time;
	    public $password;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	// read products
function read(){
 
    // select all query
    $query = "SELECT * FROM " . $this->table_name . " WHERE (email='".$_REQUEST['email_phone']."' or mobile='".$_REQUEST['email_phone']."') and `password`='".$_REQUEST['password']."'";
 
    // prepare query statement
    $stmt = $this->conn->prepare($query);
 
    // execute query
    $stmt->execute();
 
    return $stmt;
}
function forgot(){
 
    // select all query
    $query = "SELECT * FROM " . $this->table_name . " WHERE email='".$_REQUEST['email']."'";
 
    // prepare query statement
    $stmt = $this->conn->prepare($query);
 
    // execute query
    $stmt->execute();
 
    return $stmt;
}
// create product
function create(){
 
    // query to insert record
    $query = "INSERT INTO
                " . $this->table_name . "
            SET
                fullname=:fullname, email=:email, mobile=:mobile, user_type=:user_type, device_id=:device_id, device_type=:device_type, status=:status, reg_time=:reg_time, update_time=:update_time, password=:password";
 
    // prepare query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->fullname=htmlspecialchars(strip_tags($this->fullname));
	 $this->email=htmlspecialchars(strip_tags($this->email));
	  $this->mobile=htmlspecialchars(strip_tags($this->mobile));
	   $this->user_type=htmlspecialchars(strip_tags($this->user_type));
	    $this->device_id=htmlspecialchars(strip_tags($this->device_id));
		 $this->device_type=htmlspecialchars(strip_tags($this->device_type));
		    $this->status=htmlspecialchars(strip_tags($this->status));
		  $this->reg_time=htmlspecialchars(strip_tags($this->reg_time));
    $this->update_time=htmlspecialchars(strip_tags($this->update_time));
    $this->password=htmlspecialchars(strip_tags($this->password));

 
    // bind values
    $stmt->bindParam(":fullname", $this->fullname);
	 $stmt->bindParam(":email", $this->email);
	  $stmt->bindParam(":mobile", $this->mobile);
	   $stmt->bindParam(":user_type", $this->user_type);
	    $stmt->bindParam(":device_id", $this->device_id);
		 $stmt->bindParam(":device_type", $this->device_type);
		  $stmt->bindParam(":status", $this->status);
		  $stmt->bindParam(":reg_time", $this->reg_time);
		   $stmt->bindParam(":update_time", $this->update_time);
    $stmt->bindParam(":password", $this->password);
 
    // execute query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}
}