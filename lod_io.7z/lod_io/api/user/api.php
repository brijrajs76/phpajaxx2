<?php
include ('config.php');

header('Content-type: application/json');
define('UPLOAD_DIR', 'uploads/');
define('UPLOAD_DIR_SIGN', 'uploads/signature/');
define('RUNNER_IMG', '#');

define('WEB_ROOT', '#');
define('NEWPATH', '#');
define('IMAGEPATH', '#');
define('UPLOAD_DIR_FEEDBACK', '#');

define('BARCODE', '#');
$action = isset($_REQUEST['action']) ? strtolower(trim($_REQUEST['action'])) : '';
extract($_REQUEST);
switch ($action)
{
case 'Register':
	$arrResult = Register($_REQUEST);
	break;
case 'VerifyAccount':
	$arrResult = VerifyAccount($_REQUEST);
	break;
case 'GuestRegister':
	$arrResult = GuestRegister($_REQUEST);
	break;

case 'Login':
	$arrResult = Login($_REQUEST);
	break;

case 'RLogin':
	$arrResult = RLogin($_REQUEST);
	break;

case 'ForgotPassword':
	$arrResult = ForgotPassword($_REQUEST);
	break;

case 'ChangePassword':
	$arrResult = ChangePassword($_REQUEST);
	break;

case 'updateuserprofile':
	$arrResult = updateuserprofile($_REQUEST);
	break;

case 'SendParcel':
	$arrResult = SendParcel($_REQUEST);
	break;

case 'UpdateParcel':
	$arrResult = UpdateParcel($_REQUEST);
	break;

case 'DeliverParcelTime':
	$arrResult = DeliverParcelTime($_REQUEST);
	break;

case 'Conform':
	$arrResult = Conform($_REQUEST);
	break;

case 'ParcelPrice':
	$arrResult = ParcelPrice($_REQUEST);
	break;

case 'ParcelList':
	$arrResult = ParcelList($_REQUEST);
	break;

case 'UpdateRunnerLocation':
	$arrResult = UpdateRunnerLocation($_REQUEST);
	break;

case 'GetDeliveryType':
	$arrResult = GetDeliveryType($_REQUEST);
	break;

case 'InsertParcel':
	$arrResult = InsertParcel($_REQUEST);
	break;

case 'UpdateParcelPayment':
	$arrResult = UpdateParcelPayment($_REQUEST);
	break;
	
case 'GetParcelDetail':
	$arrResult = GetParcelDetail($_REQUEST);
	break;	
	
case 'GetAllParcel':
	$arrResult = GetAllParcel($_REQUEST);
	break;
case 'GetDistancesssss':
	$arrResult = GetDistancesssss($_REQUEST);
	break;
case 'GetRunnerProfile':
	$arrResult = GetRunnerProfile($_REQUEST);
	break;	
case 'GetUserProfile':
	$arrResult = GetUserProfile($_REQUEST);
	break;	
case 'AcceptParcel':
	$arrResult = AcceptParcel($_REQUEST);
	break;
case 'ParcelDeliveryStatus':
	$arrResult = ParcelDeliveryStatus($_REQUEST);
	break;
case 'ParcelDeliveryComplete':
	$arrResult = ParcelDeliveryComplete($_REQUEST);
	break;
case 'ForgotPasswordForRunner':
	$arrResult = ForgotPasswordForRunner($_REQUEST);
	break;	
case 'UserFeedback':
	$arrResult = UserFeedback($_REQUEST);
	break;
case 'FeedbackList':
	$arrResult = FeedbackList($_REQUEST);
	break;
case 'testing':
        $arrResult = testing($_REQUEST);
        break;
case 'testing2':
        $arrResult = testing2($_REQUEST);
        break;
case 'History':
        $arrResult = History($_REQUEST);
        break;	
case 'Logout':
        $arrResult = Logout($_REQUEST);
        break;
case 'LogoutUser':
        $arrResult = LogoutUser($_REQUEST);
        break;
		
case 'NotificationList':
        $arrResult = NotificationList($_REQUEST);
        break;  
case 'ParcelDriverStatus':
        $arrResult = ParcelDriverStatus($_REQUEST);
        break;
case 'NotificationStatus':
        $arrResult = NotificationStatus($_REQUEST);
        break;	
case 'Applyforaccount':
        $arrResult = Applyforaccount($_REQUEST);
        break;	
case 'Accountpayment':
        $arrResult = Accountpayment($_REQUEST);
        break;	
case 'BillingList':
        $arrResult = BillingList($_REQUEST);
        break;	
case 'Payamount':
        $arrResult = Payamount($_REQUEST);
        break;
case 'CardSave':
        $arrResult = CardSave($_REQUEST);
        break;
case 'CardList':
        $arrResult = CardList($_REQUEST);
        break;
		
		
default:
	$arrResult = array(
		'success' => 0,
		'msg' => "No Web services Found"
	);
}

$output = json_encode($arrResult);
print_r($output);

 
 // login database
// https://infograins.com/INFO01/motoxpress/api/api.php?action=CardSave&parcel_id=1&user_id=56hh&card_type=parcelpayment&exp_month=account&exp_year=as@gmail.com&card_number=123

function CardSave($data)
{
	$output = array();
	if ( $data['user_id'] == NULL  || $data['card_type'] == NULL || $data['exp_month'] == NULL  || $data['exp_year'] == NULL || $data['card_number'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "parameter should not be Empty";
		return $output;
	}
	else
	if ($data['user_id'] != '' || $data['card_type'] != '' || $data['exp_month'] != '' || $data['exp_year'] != ''  || $data['card_number'] != '')
	{
		$result = getProfilebyidss($data['user_id']);
		if ($result == 0)
		{
			$output['success'] = "0";
			$output['msg'] = "This user is not valid.";
			return $output;
		}
		$results = getcarddetailsbyid($data['user_id']);
		if ($results == 1)
		{
			$output['success'] = "0";
		 	$output['msg'] = "You already saved card.";
			return $output;
		}
		else
		{
				$date = date('Y-m-d H:i:s');
			$sql="insert into `card_tbl` SET `userid`='".$data['user_id']."',`cardtype`='".$data['card_type']."',`holder`='',`card_number`='".$data['card_number']."',`ex_month`='".$data['exp_month']."',`ex_year`='".$data['exp_year']."',`wallet_amount`='',`ccv`='',`date`='".$date."'";
			$sqlquery=mysql_query($sql);
			if($sqlquery)
			{
			$output['success'] = "1";
			$output['msg'] = "Successfully inserted";
			return $output;
			
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "some error";
			return $output;
		}
		}
		
	}
}
 
 function getcarddetailsbyid($userid)
{
	 $sql = "SELECT * FROM card_tbl WHERE userid ='" . $userid . "'";
	$sqlresult = mysql_query($sql);
	$num = mysql_num_rows($sqlresult);
	if ($num == 0)
	{
		return "0";
	}
	else
	{
		return "1";
	}
}
 
 function CardList($data)
{
	$output = array();
	if ($data['userid'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else 
	{
	
		$sql = "SELECT * FROM `card_tbl` WHERE `userid` = '" . $data['userid'] . "'";
        $sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			$i = 0;
			while ($row = mysql_fetch_array($sqlquery))
			{
				$sqlarray[$i]['id'] = $row['id'];
				$sqlarray[$i]['cardtype'] = $row['cardtype'];
				$sqlarray[$i]['card_number'] = $row['card_number'];
				$sqlarray[$i]['ex_month'] = $row['ex_month'];
				$sqlarray[$i]['ex_year'] = $row['ex_year'];
                $sqlarray[$i]['date'] = $row['date'];
				
				$i++;
			}
		
			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['Detail'] = $sqlarray;
			return $output;
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "No data Found";
			return $output;
		}
	}
}
 
 
 	function BillingList($data)
{
	$output = array();
	if ($data['userid'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else 
	{
	
		$sql = "SELECT * FROM `transaction_tbl` WHERE `user_id` = '" . $data['userid'] . "'";
        $sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			$i = 0;
			while ($row = mysql_fetch_array($sqlquery))
			{
				$sqlarray[$i]['id'] = $row['id'];
				$sqlarray[$i]['parcelid'] = $row['parcel_id'];
				$sqlarray[$i]['userid'] = $row['user_id'];
				$sqlarray[$i]['payment_method'] = $row['payment_method'];
				$sqlarray[$i]['transaction_id'] = $row['transaction_id'];
                $sqlarray[$i]['ac_no'] = $row['ac_no'];
				$sqlarray[$i]['amount'] = $row['amount'];
				$sqlarray[$i]['date'] = $row['date'];
				$sqll = "SELECT * FROM `moto_parcle_orders` WHERE `id` = '".$row['parcel_id']."'";
		        $sqlqueryy = mysql_query($sqll);
		
			
			while ($roww = mysql_fetch_array($sqlqueryy))
			{
			    $sqlarray[$i]['parcelid'] = $roww['id'];
			    $sqlarray[$i]['pickupaddress'] = $roww['picupaddress'];
				$sqlarray[$i]['dropoffaddress'] = $roww['dropoffaddress'];
				$sqlarray[$i]['pickuptime'] = $roww['pic_at_time'];
				$sqlarray[$i]['total_cost'] = $roww['total_cost'];
				$sqlarray[$i]['parcle_type'] = $roww['parcle_type'];
				$sqlarray[$i]['date'] = $roww['cdate'];


				$i++;
			}
			}
			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['Detail'] = $sqlarray;
			return $output;
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "No data Found";
			return $output;
		}
	}
}

 
 function Payamount($data)
{
	$output = array();
	if ($data['userid'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else 
	{
	
		$sql = "SELECT SUM(amount) AS value_sum FROM `transaction_tbl` WHERE `user_id` = '" . $data['userid'] . "'";
        $sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			    $row = mysql_fetch_array($sqlquery);
				//$sqlarray['userid'] = $row['user_id'];
				//$sqlarray['payment_method'] = $row['payment_method'];
               // $sqlarray['ac_no'] = $row['ac_no'];
				$sqlarray['total_amount'] = $row['value_sum'];
               // $sqlarray['total_amount'] += $num['amount'];

			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['total_amount'] = $row['value_sum'];
			return $output;
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "No notification Found";
			return $output;
		}
	}
}
 
//Logout user
function Applyforaccount($data) {  
    $output = array();
    if ($data['email'] == NULL) {
        $output['success'] = "0";
        $output['msg'] = "email should not be Empty";
        return $output;
    }
	else if($data['email']!='')
	{ 
		
 $files = array("doc/Credit_Application.docx");
$to = $data['email'];
$from = "info@infograins.com"; 
$subject ="New Account Application"; 
$message = "Hello,
Thank you for applying new account in motoxpress.com.Please fill and revert in same mail.A member of our  support team will contact in two bussiness days.
thank you,
motoxpress team";
$headers = "From: $from";
$semi_rand = md5(time()); 
$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 
 
// headers for attachment 
$headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
 
// multipart boundary 
$message = "This is a multi-part message in MIME format.\n\n" . "--{$mime_boundary}\n" . "Content-Type: text/plain; charset=\"iso-8859-1\"\n" . "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n"; 
$message .= "--{$mime_boundary}\n";
 
// preparing attachments
for($x=0;$x<count($files);$x++){
	$file = fopen($files[$x],"rb");
	$data = fread($file,filesize($files[$x]));
	fclose($file);
	$data = chunk_split(base64_encode($data));
	$message .= "Content-Type: {\"application/octet-stream\"};\n" . " name=\"$files[$x]\"\n" . 
	"Content-Disposition: attachment;\n" . " filename=\"$files[$x]\"\n" . 
	"Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
	$message .= "--{$mime_boundary}\n";
}
 
// send
 
$ok = @mail($to, $subject, $message, $headers); 
if($ok)
			{
	                $output['success'] = "1";
					$output['msg'] = "successfully send .please check your mail"; 
					  return $output; 
} else { 
                     $output['success'] = "0";
					$output['msg'] = "error";
					  return $output; 
} 
			
	}
}

// login database
// https://infograins.com/INFO01/motoxpress/api/api.php?action=Accountpayment&parcel_id=1&user_id=56hh&payment_type=parcelpayment&payment_method=account&email=as@gmail.com&account_no=123

function Accountpayment($data)
{
	$output = array();
	if ($data['parcel_id'] == NULL || $data['user_id'] == NULL  || $data['payment_method'] == NULL || $data['amount'] == NULL  || $data['account_no'] == NULL || $data['email'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "parameter should not be Empty";
		return $output;
	}
	else
	if ($data['parcel_id'] != '' || $data['user_id'] != '' || $data['payment_method'] != '' || $data['amount'] != ''  || $data['account_no'] != ''|| $data['email'] != '')
	{
		$result = getpaymentdetailsbyemail($data['account_no'],$data['email']);
		if ($result == 0)
		{
			$output['success'] = "0";
			$output['msg'] = "Enter the valid account number.";
			return $output;
		}
		else
		{
				$date = date('Y-m-d H:i:s');
			$sql="insert into `transaction_tbl` SET `parcel_id`='".$data['parcel_id']."',`user_id`='".$data['user_id']."',`payment_type`='',`payment_method`='".$data['payment_method']."',`transaction_id`='',`status`='1',`amount`='".$data['amount']."',`ac_no`='".$data['account_no']."',`date`='".$date."'";
			$sqlquery=mysql_query($sql);
			if($sqlquery)
			{
			$output['success'] = "1";
			$output['msg'] = "Successfully payment";
			return $output;
			
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "some error";
			return $output;
		}
		}
		
	}
}

function getpaymentdetailsbyemail($ac,$Email)
{
	$sql = "SELECT ac,email FROM ac_tbl WHERE ac ='".$ac."' and email='".$Email."'";
	$sqlresult = mysql_query($sql);
	$num = mysql_num_rows($sqlresult);
	if ($num == 0)
	{
		return "0";
	}
	else
	{
		return "1";
	}
}

//Logout user
function NotificationStatus($data) {  
    $output = array();
    if ($data['userid'] == NULL || $data['status'] == NULL) {
        $output['success'] = "0";
        $output['msg'] = "userid should not be Empty";
        return $output;
    }
	else if($data['userid']!='' || $data['status']!='')
	{ 
		
   
		   	$sql="UPDATE `moto_users` SET `noti_status`='".$data['status']."' WHERE userid='".$data['userid']."'";
			$sqlquery=mysql_query($sql);
			if($sqlquery)
			{  
				$output['success'] = "1";
				if($data['status']=='1'){
					$output['msg'] = "Notification on"; 
					$output['noti_status'] = "1"; 
				}
				else
				{
					$output['msg'] = "Notification off"; 
						$output['noti_status'] = "0"; 
					
				}
				
				return $output; 
			}
		
		else
		{
		        $output['success'] = "0";
				$output['msg'] = "some error"; 
				return $output;	
		}
			
	}
}
//Logout user
function Logout($data) {  
    $output = array();
    if ($data['runnerid'] == NULL) {
        $output['success'] = "0";
        $output['msg'] = "runnerid should not be Empty";
        return $output;
    }
	else if($data['runnerid']!='')
	{ 
		$result = getProfilebyidsss($data['runnerid']);
		if ($result == '0')
		{
			$output['success'] = "0";
			$output['msg'] = "Runner not in database!";
			return $output;
		}
		else
		{
   
			$sql="UPDATE `moto_runner` SET `deviceid`='' WHERE rid='".$data['runnerid']."'";
			$sqlquery=mysql_query($sql);
			if($sqlquery)
			{
				$output['success'] = "1";
				$output['msg'] = "Logout Successfully"; 
				return $output; 
			}
		
		else
		{
		        $output['success'] = "0";
				$output['msg'] = "Logout not Successfully"; 
				return $output;	
		}
			
	}
	}
}

//Logout user
function LogoutUser($data) {  
    $output = array();
    if ($data['userid'] == NULL) {
        $output['success'] = "0";
        $output['msg'] = "userid should not be Empty";
        return $output;
    }
	else if($data['userid']!='')
	{ 
		 
   $result = getProfilebyidss($data['userid']);
		if ($result == '0')
		{
			$output['success'] = "0";
			$output['msg'] = "User not in database!";
			return $output;
		}
		else
		{
			$sql="UPDATE `moto_users` SET `device_id`='' WHERE userid='".$data['userid']."'";
			$sqlquery=mysql_query($sql);
			if($sqlquery)
			{
				$output['success'] = "1";
				$output['msg'] = "Logout Successfully"; 
				return $output; 
			}
		
		else
		{
		        $output['success'] = "0";
				$output['msg'] = "Logout not Successfully"; 
				return $output;	
		}
			
	}
	}
}


function testing($data) 
{
	$message1 = 'job'; 
	$message2 = "you got new job by ravi "; 
	$deviceid='c0bde2568d2065f1eed10765c44878888b763f7b38117a8bc856e8c4a693908f';
	$registatoin_ids = array($deviceid);
$message123 = array("msg" => $message1,"notification" => $message2,"parcelid" => '1',"userid" =>'1',"notitype" =>'demo') ;
					 //$result1=sendnotificationiosDriver($registatoin_ids,$message123);   
	$result1=sendnotificationiosDriver($registatoin_ids,$message123);
	$output=array();
	$output['RESULT'] = "1"; 
    $output['msg'] = $result1;
    return $output; 
} 

function testing2($data) 
{
	$message1 = 'job'; 
	$message2 = "you got new job by raj "; 
	$deviceid='cRNIkT7A4r4:APA91bF_LwuVf7rfomS3mMNs380yra_PnODB87JKls9jZ_q4JsVOvalcbWpji4SuLYGDT2Wzyb2U83POMcBa3JU6U39ViJ2Bl6tgFdyc4wRLgWKp9nfrKMzaz4dKqaQdyHSCt1XqjB5Y';
	$registatoin_ids = array($deviceid);
$message123 = array("msg" => $message1,"notification" => $message2,"notitype" =>'new_parcel') ;
					 //$result1=sendnotificationiosDriver($registatoin_ids,$message123); 
//sendMessage($data,$target){					 
	echo $result1=sendMessagedriver($message123,$registatoin_ids);
	$output=array();
	$output['RESULT'] = "1"; 
    $output['msg'] = $result1;
    return $output; 
}  


// register user
//http://infograins.com.208-91-199-7.md-plesk-web2.webhostbox.net/INFO01/motoxpress/api/api.php?action=Register&fullname=abdul&mobile=7389360332&email=abdul.infograins@gmail.com&password=123456&device_type=17747&deviceid=74747&lat=4747&long=74747.00

function Register($data)
{
	$output = array();

	// Check that All Fields are not Empty

	if ($data['fullname'] == NULL || $data['email'] == NULL || $data['mobile'] == NULL || $data['password'] == NULL || $data['device_type'] == NULL || $data['deviceid'] == NULL || $data['lat'] == NULL || $data['long'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else if ($data['fullname'] != '' || $data['email'] != '' || $data['mobile'] != '' || $data['password'] != '' || $data['device_type'] != '' || $data['deviceid'] != '' || $data['lat'] != NULL || $data['long'] != NULL)
	{
		$result = getProfileCheckEmail($data['email']); //Email is Present or Not in Database Function
		if ($result == 1)
		{
			$output['success'] = 0;
			$output['msg'] = "Email Already Exist";
			return $output;
		}
		else
		{ 
 $sql = "SELECT * FROM `moto_users` WHERE `device_token` = '" . $data['device_token'] . "'";
		$sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			date_default_timezone_set('Asia/Calcutta');
			$date = date('Y-m-d H:i:s');
			$num_str = mt_rand(1000,9999);
		     $query = "update  `moto_users` set `fullname`='".$data['fullname']. "',`email`='" . $data['email'] . "',`mobile`='" . $data['mobile'] . "',`password`='".base64_encode($data['password'])."', `device_id`='" . $data['deviceid'] . "',`lat`='" . $data['lat'] . "', `long`='" . $data['long'] . "', `device_type`= '" . $data['device_type'] . "',`regis_date`='$date',`last_login`='$date',`account_code`='$num_str',`user_type`='Autho' ,`filter_status`='2' where device_token='".$data['device_token']."'";
			
			$sqlquery = mysql_query($query);
			if ($sqlquery)
			{
			$to = $data['email'];
                    
					$message ='<table width="100%" align="center"><tbody><tr>
               	  <td valign="top" align="center" style="font-size:10px;line-height:125%;font-family:Arial,Helvetica,sans-serif;background-color:#ffffff;border-top:3px solid #cb0000">
                    	<table width="600" cellspacing="0" cellpadding="0" border="0" style="max-width:600px">
                        	<tbody><tr>
                            	<td width="600" valign="top" height="70" style="background:#f1f1f1;line-height:125%;text-align:center;padding-top:15px;padding-bottom:15px">
                                
                                		<img width="200" style="width:200px!important" src="https://ci4.googleusercontent.com/proxy/1ysunxLNk9cKo30Sg7GiDM-iHuoV7QAbt0kUqtmvis6o__u7jyPPI5yG3vS2wGGalkLTLcJ_OPNVtJ4BZCv7Wxxf0zEXU_fSU-8=s0-d-e1-ft#https://infograins.com/INFODE/pankaj/logo-xpress.png" class="CToWUd">
                                </td>
                              	
                            </tr><tr>
                         </tr></tbody></table>
                    </td>
                </tr>        
               
                <tr>
                	<td valign="top" bgcolor="#FFFFFF" align="center" style="background-color:#ffffff;font-family:Arial,Helvetica,sans-serif;color:#505050;font-size:14px">
                    	<u></u>	
                            <u></u><u></u>
                            <u></u><u></u>
                            <u></u><table cellspacing="0" cellpadding="0" border="0" style="width:600px;background:#f1f1f1;border-collapse:collapse">
                        
                            <tbody><tr>
                            	<td width="100%" valign="middle" height="21" align="left" style="padding:10px;padding-top:30px;padding-bottom:0px">
                                	<table width="100%" height="1" cellspacing="0" cellpadding="0" border="0">
                                    	<tbody><tr>
                                        	<td valign="top" style="width:100%;padding-bottom:3px;color:#383838;font-size:20px;font-style:italic;font-weight:normal;font-family:Georgia,Times New Roman,Times,serif;border-bottom:1px solid #ececea;text-align:center">
	                                            
	                                              <u></u>Account Registration<u></u> 
	                                             
                                        	</td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                          
                        	<tr>
                            	<td valign="top" align="center" style="padding-bottom:20px">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody><tr>
                                            <td valign="top" style="padding-top:30px;padding-left:10px;padding-right:10px;padding-bottom:20px;text-align:left"><span><u></u><h3>Hello '.ucfirst($data['fullname']).',</h3>
											<p>Congratulation! your account has been created in MotoExpress.com . Please verify your account using below verification code.<br>
											<br></p>
											
											<h3>Your Email : <a target="_blank" href='.$data['email'].'>'.$data['email'].'</a></h3></span><h3>Your Verification code :'.$num_str.'</h3><span>
											
											<p style="margin-bottom:0px"><br>Thank You<br>MotoXpress Team</p>
											<u></u>
											</span></td>
                                        </tr>
                                    </tbody></table>
                                    
                                    <table width="100" cellspacing="0" cellpadding="0" border="0" align="center" style="border-collapse:collapse">
                                    	<tbody>
                                        	                   
                                         </tbody>
                                 	</table>
  								 
                                </td>
                            </tr>
                         
                        </tbody></table>
                    </td> 
              </tr>   
              <tr>
              	<td valign="top" align="center" style="background-color:#1f1f1f">
                	<span class="HOEnZb"><font color="#888888">
                         </font></span><span class="HOEnZb"><font color="#888888">
					 </font></span><table width="600" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:600px">
                    	<tbody><tr>
                        	<td valign="top" style="text-align:left;padding:10px;color:#b2b2b2;font-family:Arial,Helvetica,sans-serif;font-size:10px;line-height:150%">
                                                 <u></u>  
                         
					&copy; Copyright 2016 Infograins Software Solutions. All Rights Reserved.
					<u></u><br><span class="HOEnZb"><font color="#888888">
                                            	
                   </font></span></td></tr></tbody></table><span class="HOEnZb"><font color="#888888">
                  </font></span></td></tr></tbody></table>';
                    $subject = "Account Registration";
                    $headers  = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                    $headers .="From: info@infograins.com  \r\n ";
                    mail($to, $subject, $message, $headers);  
				$s = getProfilebydevice_token($data['device_token']);
				$output["msg"] = 'Registered Succesfully';
				$output["success"] = "1";
				$output["userdetails"] = $s;
				$output['usertype'] = "Autho";
				return $output;
			}
			else
			{
				$output["msg"] = 'an Error has been Occurred Please Try Again';
				$output["success"] = "0";
				return $output;
			}
		}
		else
		{
			date_default_timezone_set('Asia/Calcutta');
			$date = date('Y-m-d H:i:s');
			$num_str = mt_rand(1000,9999);
		    $query = "INSERT INTO `moto_users` (`user_type`,`filter_status`,`fullname`,`email`,`mobile`, `password`,`profile_image`, `device_id`, `device_token`,`device_type`,`lat`,`long`,`status`,`regis_date`,`last_login`,`account_verify`,`account_code`,`noti_status`) VALUES('Autho','2','".$data['fullname']."','" . $data['email']. "','" . $data['mobile'] . "','" . base64_encode($data['password']) . "',' ','". $data['deviceid']."','".mysql_real_escape_string($data['device_token'])."','".$data['device_type']."','".$data['lat']."','".$data['long']."','1','$date','$date','0','$num_str','1')";
       
			$sqlquery = mysql_query($query);
			$abc = mysql_insert_id();
			
			if ($sqlquery)
			{
				    $to = $data['email'];
                    
					$message ='<table width="100%" align="center"><tbody><tr>
               	  <td valign="top" align="center" style="font-size:10px;line-height:125%;font-family:Arial,Helvetica,sans-serif;background-color:#ffffff;border-top:3px solid #cb0000">
                    	<table width="600" cellspacing="0" cellpadding="0" border="0" style="max-width:600px">
                        	<tbody><tr>
                            	<td width="600" valign="top" height="70" style="background:#f1f1f1;line-height:125%;text-align:center;padding-top:15px;padding-bottom:15px">
                                
                                		<img width="200" style="width:200px!important" src="https://ci4.googleusercontent.com/proxy/1ysunxLNk9cKo30Sg7GiDM-iHuoV7QAbt0kUqtmvis6o__u7jyPPI5yG3vS2wGGalkLTLcJ_OPNVtJ4BZCv7Wxxf0zEXU_fSU-8=s0-d-e1-ft#https://infograins.com/INFODE/pankaj/logo-xpress.png" class="CToWUd">
                                </td>
                              	
                            </tr><tr>
                         </tr></tbody></table>
                    </td>
                </tr>        
               
                <tr>
                	<td valign="top" bgcolor="#FFFFFF" align="center" style="background-color:#ffffff;font-family:Arial,Helvetica,sans-serif;color:#505050;font-size:14px">
                    	<u></u>	
                            <u></u><u></u>
                            <u></u><u></u>
                            <u></u><table cellspacing="0" cellpadding="0" border="0" style="width:600px;background:#f1f1f1;border-collapse:collapse">
                        
                            <tbody><tr>
                            	<td width="100%" valign="middle" height="21" align="left" style="padding:10px;padding-top:30px;padding-bottom:0px">
                                	<table width="100%" height="1" cellspacing="0" cellpadding="0" border="0">
                                    	<tbody><tr>
                                        	<td valign="top" style="width:100%;padding-bottom:3px;color:#383838;font-size:20px;font-style:italic;font-weight:normal;font-family:Georgia,Times New Roman,Times,serif;border-bottom:1px solid #ececea;text-align:center">
	                                            
	                                              <u></u>Account Registration<u></u> 
	                                             
                                        	</td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                          
                        	<tr>
                            	<td valign="top" align="center" style="padding-bottom:20px">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody><tr>
                                            <td valign="top" style="padding-top:30px;padding-left:10px;padding-right:10px;padding-bottom:20px;text-align:left"><span><u></u><h3>Hello '.ucfirst($data['fullname']).',</h3>
											<p>Congratulation! your account has been created in MotoExpress.com . Please verify your account using below verification code.<br>
											<br></p>
											
											<h3>Your Email : <a target="_blank" href='.$data['email'].'>'.$data['email'].'</a></h3></span><h3>Your Verification code :'.$num_str.'</h3><span>
											
											<p style="margin-bottom:0px"><br>Thank You<br>MotoXpress Team</p>
											<u></u>
											</span></td>
                                        </tr>
                                    </tbody></table>
                                    
                                    <table width="100" cellspacing="0" cellpadding="0" border="0" align="center" style="border-collapse:collapse">
                                    	<tbody>
                                        	                   
                                         </tbody>
                                 	</table>
  								 
                                </td>
                            </tr>
                         
                        </tbody></table>
                    </td> 
              </tr>   
              <tr>
              	<td valign="top" align="center" style="background-color:#1f1f1f">
                	<span class="HOEnZb"><font color="#888888">
                         </font></span><span class="HOEnZb"><font color="#888888">
					 </font></span><table width="600" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:600px">
                    	<tbody><tr>
                        	<td valign="top" style="text-align:left;padding:10px;color:#b2b2b2;font-family:Arial,Helvetica,sans-serif;font-size:10px;line-height:150%">
                                                 <u></u>  
                         
					&copy; Copyright 2016 Infograins Software Solutions. All Rights Reserved.
					<u></u><br><span class="HOEnZb"><font color="#888888">
                                            	
                   </font></span></td></tr></tbody></table><span class="HOEnZb"><font color="#888888">
                  </font></span></td></tr></tbody></table>';
                    $subject = "Account Registration";
                    $headers  = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                    $headers .="From: info@infograins.com  \r\n ";
                    mail($to, $subject, $message, $headers);  
				$s = getProfilebyIds($abc);
				$output["msg"] = 'Registered Succesfully';
				$output["success"] = "1";
				$output["userdetails"] = $s;
				$output['usertype'] = "Autho";
				return $output;
			}
			else
			{
				$output["msg"] = 'an Error has been Occurred Please Try Again';
				$output["success"] = "0";
				return $output;
			}
		}
			// }

		}
	}
	$output["msg"] = 'an Error has been Occurred Please Try Again';
				$output["success"] = "0";
				return $output;
}

// Check that Email is not Present in Database Else it Returns a Error Message

function getProfileCheckEmail($Email)
{
	$sql = "SELECT email FROM moto_users WHERE email ='" . $Email . "'";
	$sqlresult = mysql_query($sql);
	$num = mysql_num_rows($sqlresult);
	if ($num == 0)
	{
		return "0";
	}
	else
	{
		return "1";
	}
}

// Check that Email is not Present in Database Else it Returns a Error Message

function getProfileCheckusername($fullname)
{
	$sql = "SELECT fullname FROM moto_users WHERE fullname ='" . $fullname . "'";
	$sqlresult = mysql_query($sql);
	$num = mysql_num_rows($sqlresult);
	if ($num == 0)
	{
		return "0";
	}
	else
	{
		return "1";
	}
}

// login database
// https://infograins.com/INFO01/motoxpress/api/api.php?action=Login&email=vgfdg&password=56hh&deviceid=12&device_type=12

function Login($data)
{
	$output = array();
	if ($data['email'] == NULL || $data['password'] == NULL || $data['deviceid'] == NULL || $data['device_type'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "username and Password should not be Empty";
		return $output;
	}
	else
	if ($data['email'] != '' || $data['password'] != '' || $data['deviceid'] != '' || $data['device_type'] != '')
	{
		$result = getloginbyemail($data['email'], $data['password']);
		if ($result == NULL)
		{
			$output['success'] = "0";
			$output['msg'] = "Invalid Login details";
			return $output;
		}
		else if($result['status']=='0')
			{ 
		    $output['success'] = "2";
			$output['msg'] = "you have no longer this account.please contact to support!";
			return $output;
			}
		else
		{
			if($result['account_verify']=='1')
			{ 
			$userlatlong = updatelatlong($result['userid'], $data['deviceid'], $data['device_type']);
			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['userdetails'] = $result;
			$output['usertype'] = "Autho";
			return $output;
			}
			else
			{
				$output['success'] = "0";
			$output['msg'] = "Account not verify";
			return $output;
			}
		}
	}
}

// login database
// https://infograins.com/INFO01/motoxpress/api/api.php?action=RLogin&email=vgfdg&password=56hh&deviceid=12&device_type=12

function RLogin($data)
{
	$output = array();
	if ($data['username'] == NULL || $data['password'] == NULL || $data['deviceid'] == NULL || $data['device_type'] == NULL || $data['lat'] == NULL || $data['long'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "username and Password should not be Empty";
		return $output;
	}
	else
	if ($data['username'] != '' || $data['password'] != '' || $data['deviceid'] != '' || $data['device_type'] != '' || $data['lat'] != '' || $data['long'] != '')
	{
		$result = getloginbyemailss($data['username'], $data['password']);
		if ($result == NULL)
		{
			$output['success'] = "0";
			$output['msg'] = "Invalid Login details";
			return $output;
		}
		else
		{
			$userlatlong = updatelatlongss($result['rid'], $data['deviceid'], $data['device_type']);
			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['userdetails'] = $result;
			return $output;
		}
	}
}

function getloginbyemail($username, $pass)
{
	$pass = base64_encode($pass);
	$sql = "SELECT * FROM `moto_users` WHERE `email` = '" . strtolower($username) . "' AND `password` = '" . $pass . "'";
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num == 1)
	{
		while ($row = mysql_fetch_array($sqlquery))
		{
			$sqlarray['userid'] = $row['userid'];
			$sqlarray['fullname'] = $row['fullname'];
			$sqlarray['email'] = $row['email'];
			$sqlarray['mobile'] = $row['mobile'];
$sqlarray['account_verify'] = $row['account_verify'];
$sqlarray['noti_status'] = $row['noti_status'];
$sqlarray['status'] = $row['status'];
			// $sqlarray['lat']=$row['lat'];
			// $sqlarray['long']=$row['long'];

		}

		return $sqlarray;
	}
}

function updatelatlong($userid, $deviceid, $devicetype)
{
	 $sql = "update `moto_users` set `device_id`='" . $deviceid . "',`device_type`='" . $devicetype . "' where `userid`='" . $userid . "'";
	$sqlquery = mysql_query($sql);
	return "1";
}


function getloginbyemailss($username, $pass)
{

	// $pass=  base64_encode($pass);

	$sql = "SELECT * FROM `moto_runner` WHERE `username` = '" . strtolower($username) . "' AND `password` = '" . $pass . "'";
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num == 1)
	{
		while ($row = mysql_fetch_array($sqlquery))
		{
			$sqlarray['rid'] = $row['rid'];
			$sqlarray['fullname'] = $row['username'];
			$sqlarray['email'] = $row['email'];
			$sqlarray['mobile'] = $row['mobile'];
			$sqlarray['profileimage'] = RUNNER_IMG . $row['profile_image'];

			// $sqlarray['lat']=$row['lat'];
			// $sqlarray['long']=$row['long'];

		}

		return $sqlarray;
	}
}

function updatelatlongss($userid, $deviceid, $devicetype)
{
	$sql = "update `moto_runner` set `deviceid`='" . $deviceid . "',`device_type`='" . $devicetype . "' where `rid`='".$userid."'";
	$sqlquery = mysql_query($sql);
	return "1";
}



// infograins.com.208-91-199-7.md-plesk-web2.webhostbox.net/INFO01/motoxpress/api/api.php?action=ForgotPassword&email=admin@gmail.com

function ForgotPassword($data)
{
	$output = array();
	if ($data['email'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "Please Enter Email";
		return $output;
	}
	else
	if ($data['email'] != '')
	{
		$result = checkvalidemail(strtolower($data['email'])); //Correct Email Check Function
		if ($result == 1)
		{
			$output['success'] = "0";
			$output['msg'] = "Email Not Valid";
			return $output;
		}
		else
		if ($result == 0)
		{
			$result = getProfilebyEmail($data['email']);
			if ($result == NULL)
			{
				$output['success'] = "0";
				$output['msg'] = "Invalid Email or Email Not Present in Our MOTO DB";
				return $output;
			}
			else
			{
				 $password = base64_decode($result['password']);
				 $to = $data['email'];
				
				 $message = '<table width="100%" align="center">
                 
                <tbody>
            
                <tr>
               	  <td valign="top" align="center" style="font-size:10px;line-height:125%;font-family:Arial,Helvetica,sans-serif;background-color:#ffffff;border-top:3px solid #cb0000">
                    	<table width="600" cellspacing="0" cellpadding="0" border="0" style="max-width:600px">
                        	<tbody><tr>
                            	<td width="600" valign="top" height="70" style="background:#f1f1f1;line-height:125%;text-align:center;padding-top:15px;padding-bottom:15px">
                                
                                		<img width="200" style="width:200px!important" src="https://ci4.googleusercontent.com/proxy/1ysunxLNk9cKo30Sg7GiDM-iHuoV7QAbt0kUqtmvis6o__u7jyPPI5yG3vS2wGGalkLTLcJ_OPNVtJ4BZCv7Wxxf0zEXU_fSU-8=s0-d-e1-ft#https://infograins.com/INFODE/pankaj/logo-xpress.png" class="CToWUd">
                                </td>
                              	
                            </tr><tr>
                         </tr></tbody></table>
                    </td>
                </tr>        
               
                <tr>
                	<td valign="top" bgcolor="#FFFFFF" align="center" style="background-color:#ffffff;font-family:Arial,Helvetica,sans-serif;color:#505050;font-size:14px">
                    	<u></u>	
                            <u></u><u></u>
                            <u></u><u></u>
                            <u></u><table cellspacing="0" cellpadding="0" border="0" style="width:600px;background:#f1f1f1;border-collapse:collapse">
                       
                            <tbody><tr>
                            	<td width="100%" valign="middle" height="21" align="left" style="padding:10px;padding-top:30px;padding-bottom:0px">
                                	<table width="100%" height="1" cellspacing="0" cellpadding="0" border="0">
                                    	<tbody><tr>
                                        	<td valign="top" style="width:100%;padding-bottom:3px;color:#383838;font-size:20px;font-style:italic;font-weight:normal;font-family:Georgia,Times New Roman,Times,serif;border-bottom:1px solid #ececea;text-align:center">
	                                            
	                                              <u></u>Forgot Password Details <u></u> 
	                                             
                                        	</td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                          <tr>
                            	<td valign="top" align="center" style="padding-bottom:20px">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody><tr>
                                            <td valign="top" style="padding-top:30px;padding-left:10px;padding-right:10px;padding-bottom:20px;text-align:left"><span><u></u><h3>Hello '.ucfirst($result['fullname']).',</h3>
											<p>Congratulation! Forgot your password in MotoExpress.com . Please login your account .<br>
											<br></p>
											
											<h3>Your Email : <a target="_blank" href='.$data['email'].'>'.$data['email'].'</a></h3></span><h3>Your Password :'.$password.'</h3><span>
											
											<p style="margin-bottom:0px"><br>Thank You<br>MotoXpress Team</p>
											<u></u>
											</span></td>
                                        </tr>
                                    </tbody></table>
                                    
                                    <table width="100" cellspacing="0" cellpadding="0" border="0" align="center" style="border-collapse:collapse">
                                    	<tbody>
                                        	                   
                                         </tbody>
                                 	</table>
  								 
                                </td>
                            </tr>
                       </tbody></table>
                    </td> 
              </tr>   
              <tr>
              	<td valign="top" align="center" style="background-color:#1f1f1f">
                	<span class="HOEnZb"><font color="#888888">
                         </font></span><span class="HOEnZb"><font color="#888888">
					 </font></span><table width="600" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:600px">
                    	<tbody><tr>
                        	<td valign="top" style="text-align:left;padding:10px;color:#b2b2b2;font-family:Arial,Helvetica,sans-serif;font-size:10px;line-height:150%">
                                                 <u></u>  
                                                 	

&copy; Copyright 2016 Infograins Software Solutions. All Rights Reserved.
<u></u><br><span class="HOEnZb"><font color="#888888">
                                            	
                                                
                                               
                                              
                             </font></span></td></tr></tbody></table><span class="HOEnZb"><font color="#888888">
                  </font></span></td></tr></tbody></table>';
				 $subject = "Forgot Password";
			

				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .="From: info@infograins.com  \r\n ";
				$mail_sent= mail($to, $subject, $message, $headers); 
				$output['EmailSucess'] = $mail_sent ? "A password has been sent to Your Given Email ID - " . $data['email'] . "" : "Mail failed";
				$output['success'] = "1";
				$output['msg'] = "password recovered on email Please Click on Link to Change Password";
				return $output;
			}
		}
	}
}

// https://infograins.com/INFO01/motoxpress/api/api.php?action=ForgotPassword&email=admin@gmail.com

function ForgotPasswordForRunner($data)
{
	$output = array();
	if ($data['email'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "Please Enter Email";
		return $output;
	}
	else
	if ($data['email'] != '')
	{
		$result = checkvalidemail(strtolower($data['email'])); //Correct Email Check Function
		if ($result == 1)
		{
			$output['success'] = "0";
			$output['msg'] = "Email Not Valid";
			return $output;
		}
		else
		if ($result == 0)
		{
			$result = getProfilebyEmailForRunner($data['email']);
			if ($result == NULL)
			{
				$output['success'] = "0";
				$output['msg'] = "Invalid Email or Email Not Present in Our MOTO DB";
				return $output;
			}
			else
			{
				 $password = $result['password'];
				 $to = $data['email'];
				
				 $message = '<table width="100%" align="center">
                 
                <tbody>
            
                <tr>
               	  <td valign="top" align="center" style="font-size:10px;line-height:125%;font-family:Arial,Helvetica,sans-serif;background-color:#ffffff;border-top:3px solid #cb0000">
                    	<table width="600" cellspacing="0" cellpadding="0" border="0" style="max-width:600px">
                        	<tbody><tr>
                            	<td width="600" valign="top" height="70" style="background:#f1f1f1;line-height:125%;text-align:center;padding-top:15px;padding-bottom:15px">
                                
                                		<img width="200" style="width:200px!important" src="https://ci4.googleusercontent.com/proxy/1ysunxLNk9cKo30Sg7GiDM-iHuoV7QAbt0kUqtmvis6o__u7jyPPI5yG3vS2wGGalkLTLcJ_OPNVtJ4BZCv7Wxxf0zEXU_fSU-8=s0-d-e1-ft#https://infograins.com/INFODE/pankaj/logo-xpress.png" class="CToWUd">
                                </td>
                              	
                            </tr><tr>
                         </tr></tbody></table>
                    </td>
                </tr>        
               
                <tr>
                	<td valign="top" bgcolor="#FFFFFF" align="center" style="background-color:#ffffff;font-family:Arial,Helvetica,sans-serif;color:#505050;font-size:14px">
                    	<u></u>	
                            <u></u><u></u>
                            <u></u><u></u>
                            <u></u><table cellspacing="0" cellpadding="0" border="0" style="width:600px;background:#f1f1f1;border-collapse:collapse">
                       
                            <tbody><tr>
                            	<td width="100%" valign="middle" height="21" align="left" style="padding:10px;padding-top:30px;padding-bottom:0px">
                                	<table width="100%" height="1" cellspacing="0" cellpadding="0" border="0">
                                    	<tbody><tr>
                                        	<td valign="top" style="width:100%;padding-bottom:3px;color:#383838;font-size:20px;font-style:italic;font-weight:normal;font-family:Georgia,Times New Roman,Times,serif;border-bottom:1px solid #ececea;text-align:center">
	                                            
	                                              <u></u>Forgot Password Details <u></u> 
	                                             
                                        	</td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                          <tr>
                            	<td valign="top" align="center" style="padding-bottom:20px">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody><tr>
                                            <td valign="top" style="padding-top:30px;padding-left:10px;padding-right:10px;padding-bottom:20px;text-align:left"><span><u></u><h3>Hello '.ucfirst($result['username']).',</h3>
											<p>Congratulation! Forgot your password in MotoExpress.com . Please login your account .<br>
											<br></p>
											
											<h3>Your Email : <a target="_blank" href='.$data['email'].'>'.$data['email'].'</a></h3></span><h3>Your Password :'.$password.'</h3><span>
											
											<p style="margin-bottom:0px"><br>Thank You<br>MotoXpress Team</p>
											<u></u>
											</span></td>
                                        </tr>
                                    </tbody></table>
                                    
                                    <table width="100" cellspacing="0" cellpadding="0" border="0" align="center" style="border-collapse:collapse">
                                    	<tbody>
                                        	                   
                                         </tbody>
                                 	</table>
  								 
                                </td>
                            </tr>
                       </tbody></table>
                    </td> 
              </tr>   
              <tr>
              	<td valign="top" align="center" style="background-color:#1f1f1f">
                	<span class="HOEnZb"><font color="#888888">
                         </font></span><span class="HOEnZb"><font color="#888888">
					 </font></span><table width="600" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:600px">
                    	<tbody><tr>
                        	<td valign="top" style="text-align:left;padding:10px;color:#b2b2b2;font-family:Arial,Helvetica,sans-serif;font-size:10px;line-height:150%">
                                                 <u></u>  
                                                 	

&copy; Copyright 2016 Infograins Software Solutions. All Rights Reserved.
<u></u><br><span class="HOEnZb"><font color="#888888">
                                            	
                                                
                                               
                                              
                             </font></span></td></tr></tbody></table><span class="HOEnZb"><font color="#888888">
                  </font></span></td></tr></tbody></table>';
				 $subject = "Forgot Password";
			

				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .="From: info@infograins.com  \r\n ";
				$mail_sent= mail($to, $subject, $message, $headers); 
				$output['EmailSucess'] = $mail_sent ? "A password has been sent to Your Given Email ID - " . $data['email'] . "" : "Mail failed";
				$output['success'] = "1";
				$output['msg'] = "password recovered on email Please Click on Link to Change Password";
				return $output;
			}
		}
	}
}


// Check For Valid Email Whether Email is Correct or Not

function checkvalidemail($email)
{
	$regex = '/^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,3})$/';
	if (preg_match($regex, $email))
	{
		return "0";
	}
	else
	{
		return "1";
	}
}
function getProfilebyEmailForRunner($Email)
{
	$sql = "SELECT * FROM `moto_runner` WHERE `email` = '" . strtolower($Email) . "'";
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num > 0)
	{
		while ($row = mysql_fetch_array($sqlquery))
		{
			$sqlarray['rid'] = $row['rid'];
			$sqlarray['username'] = $row['username'];
			$sqlarray['email'] = $row['email'];
			$sqlarray['password'] = $row['password'];
		}

		return $sqlarray;
	}
}

function getProfilebyEmail($Email)
{
	$sql = "SELECT * FROM `moto_users` WHERE `email` = '" . strtolower($Email) . "'";
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num > 0)
	{
		while ($row = mysql_fetch_array($sqlquery))
		{
			$sqlarray['userid'] = $row['userid'];
			$sqlarray['fullname'] = $row['fullname'];
			$sqlarray['email'] = $row['email'];
			$sqlarray['password'] = $row['password'];
		}

		return $sqlarray;
	}
}

function getProfilebyId($id)
{
	$sql = "SELECT * FROM `moto_users` WHERE `userid` = '" . $id . "'";
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num > 0)
	{
		while ($row = mysql_fetch_array($sqlquery))
		{
			$sqlarray['userid'] = $row['userid'];
			$sqlarray['fullname'] = $row['fullname'];
			$sqlarray['email'] = $row['email'];
			$sqlarray['mobile'] = $row['mobile'];
			$sqlarray['password'] = $row['password'];
		}

		return $sqlarray;
	}
}

function getProfilebyIds($id)
{
	$sql = "SELECT * FROM `moto_users` WHERE `userid` = '" . $id . "'";
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num > 0)
	{
		while ($row = mysql_fetch_array($sqlquery))
		{
			$sqlarray['userid'] = $row['userid'];
			$sqlarray['fullname'] = $row['fullname'];
			$sqlarray['email'] = $row['email'];
			$sqlarray['mobile'] = $row['mobile'];
		}

		return $sqlarray;
	}
}


function getProfilebydevice_token($id)
{ 
	$sql = "SELECT * FROM `moto_users` WHERE `device_token` = '" . $id . "'";
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num > 0)
	{
		while ($row = mysql_fetch_array($sqlquery))
		{
			$sqlarray['userid'] = $row['userid'];
			$sqlarray['fullname'] = $row['fullname'];
			$sqlarray['email'] = $row['email'];
			$sqlarray['mobile'] = $row['mobile'];
		}

		return $sqlarray;
	}
}

// Change Password Function
// https://infograins.com/INFO01/motoxpress/api/api.php?action=ChangePassword&userid=1&newPassword=12&oldPassword=12

function ChangePassword($data)
{
	$output = array();
	if ($data['userid'] == NULL || $data['oldPassword'] == NULL || $data['newPassword'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter Null not allowed";
	}
	else
	if ($data['userid'] != '' || $data['oldPassword'] != '' || $data['newPassword'] != '')
	{
		$profile = getProfilebyId($data['userid']);
		if ($profile == NULL)
		{
			$output['success'] = 0;
			$output['msg'] = "Invalid Email or Email Not Present in Our Website";
			return $output;
		}
		else
		{
			$profile['password'];
			 $oldPassword = base64_encode($data['oldPassword']);
			//echo base64_decode($profile['password']);
			if ($profile['password'] == $oldPassword)
			{
				$sql = "UPDATE moto_users SET
							password = '" . base64_encode($data['newPassword']) . "'
							WHERE userid = '" . $data['userid'] . "'
							";
				$sqlquery = mysql_query($sql);
				$output['success'] = 1;
				$output['msg'] = "Password updated successfully";
			}
			else
			{
				$output['success'] = 0;
				$output['msg'] = "Check old password and Enter Correct Old Password";
			}
		}
	}

	return $output;
}

// Update user profile
// https://infograins.com/INFO01/motoxpress/api/api.php?action=updateuserprofile&userid=1&fullname=raju&email=fdfds@g.com&mobile=132

function updateuserprofile($data)
{
	$output = array();

	// Check that All Fields are not Empty

	if ($data['userid'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "Userid can not be blank!";
		return $output;
	}
	else
	if ($data['userid'] != '')
	{
		$result = getProfilebyidss($data['userid']);
		if ($result == '0')
		{
			$output['success'] = "0";
			$output['msg'] = "Userid not in database!";
			return $output;
		}
		else
		{
			$sql = "UPDATE `moto_users` SET `fullname`='" . $data['fullname'] . "',`email`='" . $data['email'] . "',`mobile`='" . $data['mobile'] . "'  WHERE userid='" . $data['userid'] . "'";
			$sqlquery = mysql_query($sql);
			$userdetails = getProfilebyIds($data['userid']);
			$output['success'] = "1";
			$output['msg'] = "Profile updated";
			$output["userdetails"] = $userdetails;
			$output["usertype"] = "Autho";
			return $output;
		}
	}
} 

// Check that userid is not Present in Database Else it Returns a Error Message

function getProfilebyidss($userid)
{
	$sql = "SELECT * FROM moto_users WHERE userid ='" . $userid . "'";
	$sqlresult = mysql_query($sql);
	$num = mysql_num_rows($sqlresult);
	if ($num == 0)
	{
		return "0";
	}
	else
	{
		return "1";
	}
}

function getProfilebyidsss($userid)
{
	$sql = "SELECT * FROM moto_runner WHERE rid ='" . $userid . "'";
	$sqlresult = mysql_query($sql);
	$num = mysql_num_rows($sqlresult);
	if ($num == 0)
	{
		return "0";
	}
	else
	{
		return "1";
	}
}
function distances($lat1, $lon1, $lat2, $lon2, $unit)
{
	$theta = $lon1 - $lon2;
	$dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
	$dist = acos($dist);
	$dist = rad2deg($dist);
	$miles = $dist * 60 * 1.1515;
	$unit = strtoupper($unit);
	if ($unit == "K")
	{
		return ($miles * 1.609344);
	}
	else
	if ($unit == "N")
	{
		return ($miles * 0.8684);
	}
	else
	{
		return $miles;
	}
}

function getFromaddress($lat1, $lon1)
{
	$url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' . trim($lat1) . ',' . trim($lon1) . '&sensor=false';
	$json = @file_get_contents($url);
	$data = json_decode($json);
	$status = $data->status;
	if ($status == "OK") return $data->results[0]->formatted_address;
	else return false;
}

function getToaddress($lat1, $lon1)
{
	$url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' . trim($lat1) . ',' . trim($lon1) . '&sensor=false';
	$json = @file_get_contents($url);
	$data = json_decode($json);
	$status = $data->status;
	if ($status == "OK") return $data->results[0]->formatted_address;
	else return false;
}

// sendparcel
// https://infograins.com/INFO01/motoxpress/api/api.php?action=SendParcel&userid=45&faddress=raj&fcompany=12&funit=hasi&taddress=raj&tcompany=12&tunit=hasi&width&height&length&t_longitude&t_latitude&f_longitude&f_latitude&device_type&pid&deice_id&quantity&parcel_type
// https://infograins.com/INFO01/motoxpress/api/api.php?action=SendParcel&t_latitude=info&t_longitude=2&f_latitude=indore&f_longitude=3

function SendParcel($data)
{
	$output = array();

	// Check that All Fields are not Empty

	if ($data['t_latitude'] == NULL || $data['t_longitude'] == NULL || $data['f_latitude'] == NULL || $data['f_longitude'] == NUll)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	elseif ($data['t_latitude'] != '' || $data['t_longitude'] != '' || $data['f_latitude'] != '' || $data['f_longitude'] != '')
	{
		$Parceldistance = distances($data['f_latitude'], $data['f_longitude'], $data['t_latitude'], $data['t_longitude'], "K");
		$Parceldistance = round($Parceldistance);
		$formaddress = getFromaddress($data['f_latitude'], $data['f_longitude']);
		$toaddress = getToaddress($data['f_latitude'], $data['f_longitude']);
		$result = getparcelbyidss($data['device_id']);
		if ($result > 0)
		{
			if ($data['parcel_type'] == 'other')
			{
				if ($data['length'] != '' && $data['width'] != '' && $data['weight'] != '' && $data['height'] != '')
				{
					$sql = "UPDATE `order_tbl` SET `faddress`='" . $formaddress . "',`fcompany`='" . $data['fcompany'] . "',`funit_no`='" . $data['funit_no'] . "',`taddress`='" . $toaddress . "',`tcompany`='" . $data['tcompany'] . "',`tunit_no`='" . $data['tunit_no'] . "',`parcel_type`='" . $data['parcel_type'] . "',`weight`='" . $data['weight'] . "',`length`='" . $data['length'] . "',`width`='" . $data['width'] . "',`height`='" . $data['height'] . "',`quantity`='" . $data['quantity'] . "',`trip_distance`='" . $Parceldistance . "' ,`pick_by`='" . $data['pick_by'] . "',`deli_by`='" . $data['deli_by'] . "',`time`='" . $data['time'] . "',`pick_contact`='" . $data['pick_contact'] . "' ,`deli_contact`='" . $data['deli_contact'] . "',`short_description`='" . $data['short_description'] . "',`deli_ins`='" . $data['deli_ins'] . "',`t_longitude`='" . $data['t_longitude'] . "',`t_latitude`='" . $data['t_latitude'] . "',`f_longitude`='" . $data['f_longitude'] . "',`f_latitude`='" . $data['f_latitude'] . "',`device_id`='" . $data['device_id'] . "',`device_type`='" . $data['device_type'] . "',`device_token`='" . $data['device_token'] . "',`photo`='" . $data['photo'] . "' WHERE id='" . $data['device_id'] . "'";
					$sqlquery = mysql_query($sql);
					$s = getparcelbyidss($data['device_id']);
					$output["msg"] = 'Order update successfully';
					$output["success"] = "1";
					$output["orderdetails"] = $s;
					return $output;
				}
				else
				{
					$output['success'] = 0;
					$output['msg'] = "Check Parameter";
					return $output;
				}
			}
			else
			{
				$sql = "UPDATE `order_tbl` SET `faddress`='" . $data['faddress'] . "',`fcompany`='" . $data['fcompany'] . "',`funit_no`='" . $data['funit_no'] . "',`taddress`='" . $data['taddress'] . "',`tcompany`='" . $data['tcompany'] . "',`tunit_no`='" . $data['tunit_no'] . "',`parcel_type`='" . $data['parcel_type'] . "',`weight`='" . $data['weight'] . "',`length`='" . $data['length'] . "',`width`='" . $data['width'] . "',`height`='" . $data['height'] . "',`quantity`='" . $data['quantity'] . "',`trip_distance`='" . $Parceldistance . "',`pick_by`='" . $data['pick_by'] . "',`deli_by`='" . $data['deli_by'] . "',`time`='" . date('Y-m-d H:i:s') . "',`pick_contact`='" . $data['pick_contact'] . "' ,`deli_contact`='" . $data['deli_contact'] . "',`short_description`='" . $data['short_description'] . "',`deli_ins`='" . $data['deli_ins'] . "',`t_longitude`='" . $data['t_longitude'] . "',`t_latitude`='" . $data['t_latitude'] . "',`f_longitude`='" . $data['f_longitude'] . "',`f_latitude`='" . $data['f_latitude'] . "',`device_id`='" . $data['device_id'] . "',`device_type`='" . $data['device_type'] . "',`device_token`='" . $data['device_token'] . "',`photo`='" . $data['photo'] . "' WHERE id='" . $data['device_id'] . "'";
				$sqlquery = mysql_query($sql);
				$s = getparcelbyidss($data['device_id']);
				$output["msg"] = 'Order update successfully';
				$output["success"] = "1";
				$output["orderdetails"] = $s;
				return $output;
			}
		}
		else
		{
			date_default_timezone_set('Asia/Calcutta');
			$date = date('Y-m-d H:i:s');
			 $query = "INSERT INTO `order_tbl`(`userid`,`faddress`,`fcompany`,`funit_no`, `taddress`,`tcompany`, `tunit_no`, `parcel_type`,`weight`,`length`,`width`,`height`,`quantity`,`trip_distance`,`pick_by`,`deli_by`,`time`,`pick_contact`,`deli_contact`,`short_description`,`deli_ins`,`photo`,`photo2`,`photo3`,`status`,`date`,`mdate`,`device_id`,`device_type`,`t_longitude`,`t_latitude`,`f_longitude`,`f_latitude`,`device_token`) VALUES('0','" . $data['faddress'] . "','" . $data['fcompany'] . "','" . $data['funit_no'] . "','" . $data['taddress'] . "','" . $data['tcompany'] . "', '" . $data['tunit_no'] . "', '" . $data['parcel_type'] . "', '" . $data['weight'] . "', '" . $data['length'] . "','" . $data['width'] . "','" . $data['height'] . "','" . $data['quantity'] . "', '" . $Parceldistance . "', '" . $data['pick_by'] . "', '" . $data['deli_by'] . "', '" . $date . "', '" . $data['pick_contact'] . "', '" . $data['deli_contact'] . "', '" . $data['short_description'] . "', '" . $data['deli_ins'] . "','" . $data['photo'] . "','" . $data['photo2'] . "','" . $data['photo3'] . "','1','$date','$date','" . $data['device_id'] . "','" . $data['device_type'] . "','" . $data['t_longitude'] . "','" . $data['t_latitude'] . "','" . $data['f_longitude'] . "','" . $data['f_latitude'] . "','" . $data['device_token'] . "')";
			die();
			$sqlquery = mysql_query($query);
			$abc = mysql_insert_id();
			if ($sqlquery)
			{
				$s = getorderdetailsbyid($abc);
				$output["msg"] = 'Order insert';
				$output["success"] = "1";
				$output["orderdetails"] = $s;
				return $output;
			}
			else
			{
				$output["msg"] = 'an Error has been Occurred Please Try Again';
				$output["success"] = "0";
				return $output;
			}

			// }

		}
	}
}

function getorderdetailsbyid($id)
{
	$sql = "SELECT * FROM `order_tbl` WHERE `id` = '" . $id . "'";
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num > 0)
	{
		while ($row = mysql_fetch_array($sqlquery))
		{
			$sqlarray['pid'] = $row['id'];
			$sqlarray['fcompany'] = $row['fcompany'];
			$sqlarray['funit_no'] = $row['funit_no'];
			$sqlarray['tcompany'] = $row['tcompany'];
			$sqlarray['tunit_no'] = $row['tunit_no'];
			$sqlarray['trip_distance'] = $row['trip_distance'];
			$sqlarray['time'] = $row['time'];
			$sqlarray['status'] = $row['status'];
			$sqlarray['to'] = getToaddress($row['t_latitude'], $row['t_longitude']);
			$sqlarray['from'] = getFromaddress($row['f_latitude'], $row['f_longitude']);
		}

		return $sqlarray;
	}
	else
	{
		return '0';
	}
}

function getparcelbyidss($id)
{
	$sql = "SELECT * FROM `order_tbl` WHERE `device_id` = '" . $id . "'";
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num > 0)
	{
		while ($row = mysql_fetch_array($sqlquery))
		{
			$sqlarray['pid'] = $row['id'];
			$sqlarray['fcompany'] = $row['fcompany'];
			$sqlarray['funit_no'] = $row['funit_no'];
			$sqlarray['tcompany'] = $row['tcompany'];
			$sqlarray['tunit_no'] = $row['tunit_no'];
			$sqlarray['trip_distance'] = $row['trip_distance'];
			$sqlarray['time'] = $row['time'];
			$sqlarray['status'] = $row['status'];
			$sqlarray['to'] = getToaddress($row['t_latitude'], $row['t_longitude']);
			$sqlarray['from'] = getFromaddress($row['f_latitude'], $row['f_longitude']);
		}

		return $sqlarray;
	}
	else
	{
		return '0';
	}
}

// https://infograins.com/INFO01/motoxpress/api/api.php?action=UpdateParcel&pid=45&faddress=raj&fcompany=12&funit=hasi&taddress=raj&tcompany=12&tunit=hasi&parcel_type=hasi&weight=hasi&length=hasi&width=hasi&height=hasi&quantity=hasi&trip_dustance=hasi&pick_by=hasi&deli_by=hasi&time=hasi

function UpdateParcel($data)
{
	$output = array();
	if ($data['pid'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "orderid can not be blank!";
		return $output;
	}
	else
	if ($data['pid'] != '')
	{
		$result = getparcelbyid($data['pid']);

		// $userdetails=Getuserdetailsbyid($data['userid']);

		if ($result == '0')
		{
			$output['success'] = "0";
			$output['msg'] = "orderid not in database!";
			return $output;
		}
		else
		{
			$sql = "UPDATE `order_tbl` SET `faddress`='" . $data['faddress'] . "',`fcompany`='" . $data['fcompany'] . "',`funit_no`='" . $data['funit_no'] . "',`taddress`='" . $data['taddress'] . "',`tcompany`='" . $data['tcompany'] . "',`tunit_no`='" . $data['tunit_no'] . "',`parcel_type`='" . $data['parcel_type'] . "',`weight`='" . $data['weight'] . "',`length`='" . $data['length'] . "',`width`='" . $data['width'] . "',`height`='" . $data['height'] . "',`quantity`='" . $data['quantity'] . "',`trip_dustance`='" . $data['trip_dustance'] . "' ,`pick_by`='" . $data['pick_by'] . "',`deli_by`='" . $data['deli_by'] . "',`time`='" . $data['time'] . "',`pick_contact`='' ,`deli_contact`='',`short_description`='',`deli_ins`='',`photo`='' WHERE id='" . $data['pid'] . "'";
			$sqlquery = mysql_query($sql);
			$output['success'] = "1";
			$output['msg'] = "Profile updated";
			return $output;
		}
	}
}

// https://infograins.com/INFO01/motoxpress/api/api.php?action=ParcelPrice&delivered_by=1&km=15

function ParcelPrice($data)
{
	$output = array();
	if ($data['delivered_by'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "time can not be blank!";
		return $output;
	}
	else
	if ($data['delivered_by'] != '')
	{
		$date = date('Y-m-d H:i:s');
		$d = '$';
		if ($data['delivered_by'] == 't')
		{
			$details = 15 + $data['km'] + 3.70;
			$output['success'] = "1";
			$output['msg'] = "Time Slot Details!";
			$output['id'] = "1";

			// $output['price'] = $d.''.$details;

			$time_slot1 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$time_slot2 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$time_slot3 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$time_slot4 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$output['time_slot'] = array(
				$time_slot1,
				$time_slot2,
				$time_slot3,
				$time_slot4
			);
			return $output;
		}
		elseif ($data['delivered_by'] == '1-2H')
		{
			$details = 15 + $data['km'] + 2.50;
			$output['success'] = "1";
			$output['msg'] = "Time Slot Details!";
			$output['id'] = "2";

			// $output['price'] = $d.''.$details;

			$time_slot1 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$time_slot2 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$time_slot3 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$time_slot4 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$output['time_slot'] = array(
				$time_slot1,
				$time_slot2,
				$time_slot3,
				$time_slot4
			);
			return $output;
		}
		elseif ($data['delivered_by'] == '3-4H')
		{
			$details = 15 + $data['km'] + 0.80;
			$output['success'] = "1";
			$output['msg'] = "Time Slot Details!";
			$output['id'] = "3";

			// $output['price'] = $d.''.$details;

			$time_slot1 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$time_slot2 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$time_slot3 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$time_slot4 = array(
				'time' => '12:00 PM',
				'date' => 'tommorow',
				'Price' => $d . '' . $details
			);
			$output['time_slot'] = array(
				$time_slot1,
				$time_slot2,
				$time_slot3,
				$time_slot4
			);
			return $output;
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "Not found!";
			return $output;
		}
	}
}

// https://infograins.com/INFO01/motoxpress/api/api.php?action=DeliverParcelTime&time=1

function DeliverParcelTime($data)
{
	$output = array();
	if ($data['time'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "time can not be blank!";
		return $output;
	}
	else
	if ($data['time'] != '')
	{
		$date = date('Y-m-d H:i:s');
		if ($data['time'] == '1')
		{
			$details = DeliverdDetails($data['time']);
			$output['success'] = "1";
			$output['msg'] = "Time Slot Details!";
			$output['timedetails'] = $details;
			return $output;
		}
		elseif ($data['time'] == '2-3')
		{
			$shortby = 'deliverby2';
			$details = DeliverdDetails($data['time']);
			$output['success'] = "1";
			$output['msg'] = "Time Slot Details!";
			$output['timedetails'] = $details;
			return $output;
		}
		elseif ($data['time'] == '4-5')
		{
			$shortby = 'deliverby4';
			$details = DeliverdDetails($data['time']);
			$output['success'] = "1";
			$output['msg'] = "Time Slot Details!";
			$output['timedetails'] = $details;
			return $output;
		}
		elseif ($data['time'] < '12')
		{
			$shortby = 'other';
			$details = DeliverdDetails($data['time']);
			$output['success'] = "1";
			$output['msg'] = "Time Slot Details!";
			$output['timedetails'] = $details;
			return $output;
		}
		else
		{
			$detailss = DeliverdDetailss($data['time']);
			$output['success'] = "1";
			$output['msg'] = "Time Slot Details!";
			$output['timedetails'] = $detailss;
			return $output;
		}
	}
}

// function DeliverdDetailss($timeslot)
// {
// $sqlarray['date']= $timeslot;
// $sqlarray['time']= $row['time'];
// $sqlarray['price']= $row['price'];
// return $sqlarray;
// }

function DeliverdDetails($timeslot)
{
	$sql = "SELECT * FROM `moto_timeslot` where `timeslot` = '$timeslot'";
	$sqlresult = mysql_query($sql);
	$num = mysql_num_rows($sqlresult);
	if ($num > 0)
	{
		$i = 0;
		while ($row = mysql_fetch_assoc($sqlresult))
		{
			$i++;
			$sqlarray[$i]['date'] = $row['date'];
			$sqlarray[$i]['time'] = $row['time'];
			$sqlarray[$i]['price'] = $row['price'];
		}

		return $sqlarray;
	}
	else
	{
		return '0';
	}
}

// Check that userid is not Present in Database Else it Returns a Error Message

function getparcelbyid($userid)
{
	$sql = "SELECT * FROM order_tbl WHERE id ='" . $userid . "'";
	$sqlresult = mysql_query($sql);
	$num = mysql_num_rows($sqlresult);
	if ($num == 0)
	{
		return "0";
	}
	else
	{
		return "1";
	}
}

function getparcelbyids($userid)
{
	$sql = "SELECT * FROM order_tbl WHERE device_id ='" . $userid . "'";
	$sqlresult = mysql_query($sql);
	$num = mysql_num_rows($sqlresult);
	if ($num == 0)
	{
		return "0";
	}
	else
	{
		return "1";
	}
}

// https://infograins.com/INFO01/motoxpress/api/api.php?action=Conform&deviceid=dsf&pikupname=raj&pick_contact=123$deli_name=fds&deli_contact=ds&short_description=fdf&deli_ins=hasi

function Conform($data)
{
	$output = array();
	if ($data['device_id'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "orderid can not be blank!";
		return $output;
	}
	else
	if ($data['device_id'] != '')
	{
		$result = getparcelbyids($data['device_id']);

		// $result=getparcelbyid($data['deviceid']);
		// $userdetails=Getuserdetailsbyid($data['userid']);

		if ($result == '0')
		{
			$output['success'] = "0";
			$output['msg'] = "orderid not in database!";
			return $output;
		}
		else
		{
			$uploads_dir = 'uploads/';
			$image1 = $_FILES["image0"]['name'];
			$image2 = $_FILES["image1"]['name'];
			$image3 = $_FILES["image2"]['name'];
			if ($image1 != '')
			{
				$image1 = rand(100000, 10000000) . $_FILES["image0"]['name'];
				move_uploaded_file($_FILES["image0"]["tmp_name"], $uploads_dir . $image1);
			}

			if ($image2 != '')
			{
				$image2 = rand(100000, 10000000) . $_FILES["image1"]['name'];
				move_uploaded_file($_FILES["image1"]["tmp_name"], $uploads_dir . $image2);
			}

			if ($image3 != '')
			{
				$image3 = rand(100000, 10000000) . $_FILES["image2"]['name'];
				move_uploaded_file($_FILES["image2"]["tmp_name"], $uploads_dir . $image3);
			}

			$sql = "UPDATE `order_tbl` SET `price`='" . $data['price'] . "',`pick_by`='" . $data['pickname'] . "',`deli_by`='" . $data['deli_name'] . "',`pick_contact`='" . $data['pick_contact'] . "',`deli_contact`='" . $data['deli_contact'] . "',`short_description`='" . $data['short_description'] . "',`deli_ins`='" . $data['deli_ins'] . "',`photo`='" . $image1 . "',`photo2`='" . $image2 . "',`photo3`='" . $image3 . "' WHERE device_id='" . $data['device_id'] . "'";
			$sqlquery = mysql_query($sql);
			$output['success'] = "1";
			$output['msg'] = "updated successfully";
			return $output;
		}
	}
}

function getDistance($addressFrom, $addressTo, $unit)
{

	// Change address format

	$formattedAddrFrom = str_replace(' ', '+', $addressFrom);
	$formattedAddrTo = str_replace(' ', '+', $addressTo);

	// Send request and receive json data

	$geocodeFrom = file_get_contents('https://maps.google.com/maps/api/geocode/json?address=' . $formattedAddrFrom . '&sensor=false');
	$outputFrom = json_decode($geocodeFrom);
	$geocodeTo = file_get_contents('https://maps.google.com/maps/api/geocode/json?address=' . $formattedAddrTo . '&sensor=false');
	$outputTo = json_decode($geocodeTo);

	// Get latitude and longitude from geo data

	$latitudeFrom = $outputFrom->results[0]->geometry->location->lat;
	$longitudeFrom = $outputFrom->results[0]->geometry->location->lng;
	$latitudeTo = $outputTo->results[0]->geometry->location->lat;
	$longitudeTo = $outputTo->results[0]->geometry->location->lng;

	// Calculate distance from latitude and longitude

	$theta = $longitudeFrom - $longitudeTo;
	$dist = sin(deg2rad($latitudeFrom)) * sin(deg2rad($latitudeTo)) + cos(deg2rad($latitudeFrom)) * cos(deg2rad($latitudeTo)) * cos(deg2rad($theta));
	$dist = acos($dist);
	$dist = rad2deg($dist);
	$miles = $dist * 60 * 1.1515;
	$unit = strtoupper($unit);
	if ($unit == "K")
	{
		return ($miles * 1.609344) . ' km';
	}
	else
	if ($unit == "N")
	{
		return ($miles * 0.8684) . ' nm';
	}
	else
	{
		return $miles . ' mi';
	}
}

function UpdateRunnerLocation($data)
{
	$output = array();
	if ($data['userid'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "userid can not be blank!";
		return $output;
	}
	else
	{
		$sql = "UPDATE `moto_runner` SET `lat`='" . $data['lat'] . "',`long`='" . $data['long'] . "' WHERE rid='" . $data['userid'] . "'";
		$sqlquery = mysql_query($sql);
		$output['success'] = "1";
		$output['msg'] = "Successfully updated";
		return $output;
	}
}

// https://infograins.com/INFO01/motoxpress/api/api.php?action=GuestRegister&deviceid=1234567890

function GuestRegister($data)
{
	
	$output = array();
	if ($data['device_token'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else
	{
		$sql = "SELECT * FROM `moto_users` WHERE `device_token` = '" . $data['device_token'] . "'";
		$sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			$row = mysql_fetch_array($sqlquery);
			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['userid'] = $row['userid'];
			$output['usertype'] = "Guest";
			return $output;
		}
		else
		{
			$query = "INSERT INTO `moto_users`(`device_id`,`device_token`,`status`,`user_type`,`filter_status`,`noti_status`) VALUES('".$data['deviceid']."','".$data['device_token']."',1,'Guest','2','1')";
			$sqlquery = mysql_query($query);
			$abc = mysql_insert_id();
			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['userid'] = $abc;
			$output['usertype'] = "Guest";
			return $output;
		}
	}
}

function GetDeliveryType($data)
{
	$output = array();
	if ($data['type'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else
	{
		$sql = "SELECT * FROM `moto_delivery_price` WHERE `main` = '" . $data['type'] . "'";
		$sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			$i = 0;
			while ($row = mysql_fetch_array($sqlquery))
			{
				$sqlarray[$i]['id'] = $row['id'];
				$sqlarray[$i]['name'] = $row['name'];
				$sqlarray[$i]['flatrate'] = $row['flatrate'];
				$sqlarray[$i]['kmrate'] = $row['kmrate'];
				$sqlarray[$i]['color'] = $row['color'];
				$i++;
			}

			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['List'] = $sqlarray;
			return $output;
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "No Plan Found";
			return $output;
		}
	}
}
function getstatusbyid($userid)
{
	$sql = "SELECT * FROM moto_users WHERE userid ='" . $userid . "' and status='1'";
	$sqlresult = mysql_query($sql);
	$num = mysql_num_rows($sqlresult);
	if ($num == 0)
	{
		return "0";
	}
	else
	{
		return "1";
	}
}

//http://infograins.com.208-91-199-7.md-plesk-web2.webhostbox.net/INFO01/motoxpress/api/api.php?action=InsertParcel&uid=45
function InsertParcel($data)
{
	$output = array();
	if ($data['uid'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else
	{
		$rund = time();
		$fileCount = count($_FILES['img']['name']);
		$file = '';
		for ($i = 0; $i < $fileCount; $i++)
		{
			$textfile = $rund . "" . $i . ".jpg";
			move_uploaded_file($_FILES['img']['tmp_name'][$i], "uploads/" . $textfile);
			if ($i == '0')
			{
				$file1 = $rund . "0.jpg";
				$file.= $file1;
			}

			if ($i == '1')
			{
				$file2 = $rund . "1.jpg";
				$file.= "," . $file2;
			}

			if ($i == '2')
			{
				$file3 = $rund . "2.jpg";
				$file.= "," . $file3;
			}
		}
          $date = date('Y-m-d : H:i:s');
		   // $query = "INSERT INTO `moto_parcle_orders`(`uid`,`picupaddress`, `dropoffaddress`, `picupcontactname`, `dropoffcontactname`, `pickupunitnumber`, `dropoffunitnumber`, `pickupcnatctnumber`, `dropoffcontactnumber`, `picupcompany`, `dropoffcompany`, `photo`, `short_ins`, `delivery_ins`, `noti_email`,`total_cost`, `delivery_plan`, `delivery_time`, `total_distance`, `deliver_by`, `pic_at_time`, `parcle_type`, `no_of_item`, `width`, `height`, `weight`, `length`, `delivery_status`, `payment_status`,`plat`,`plong`,`dlat`,`dlong`,`did`,`filter_status`) VALUES ('" . $data['uid'] . "','" . $data['picupaddress'] . "','" . $data['dropoffaddress'] . "','" . $data['picupcontactname'] . "','" . $data['dropoffcontactname'] . "','" . $data['pickupunitnumber'] . "','" . $data['dropoffunitnumber'] . "','" . $data['pickupcnatctnumber'] . "','" . $data['dropoffcontactnumber'] . "','" . $data['picupcompany'] . "','" . $data['dropoffcompany'] . "','" . $file . "',		'" . $data['short_ins'] . "','" . $data['delivery_ins'] . "','" . $data['noti_email'] . "','" . $data['total_cost'] . "','" . $data['delivery_plan'] . "','" . $data['delivery_time'] . "','" . $data['total_distance'] . "','" . $data['deliver_by'] . "','" . $data['pic_at_time'] . "','" . $data['parcle_type'] . "','" . $data['no_of_item'] . "','" . $data['width'] . "','" . $data['height'] . "','" . $data['weight'] . "','" . $data['length'] . "','pending', 'pending','" . $data['plat'] . "','" . $data['plong'] . "','" . $data['dlat'] . "','" . $data['dlong'] . "','0','2')";

	$result = getProfilebyidss($data['uid']);
		if ($result == '0')
		{
			$output['success'] = "0";
			$output['msg'] = "User not in database!";
			return $output;
		}
		$result = getstatusbyid($data['uid']);
		if ($result == '0')
		{
			$output['success'] = "2";
			$output['msg'] = "you have no longer this account.please contact to support!";
			return $output;
		}
		else
		{
	    
	   $query ="INSERT INTO `moto_parcle_orders`(`uid`,`barcode_img`, `tract_number`, `picupaddress`, `dropoffaddress`, `picupcontactname`, `dropoffcontactname`, `pickupunitnumber`, `dropoffunitnumber`, `pickupcnatctnumber`, `dropoffcontactnumber`, `picupcompany`, `dropoffcompany`, `photo`,`short_ins`, `delivery_ins`, `internal`, `noti_email`, `deli_noti_email`, `payment_method`, `cdate`,`total_cost`, `delivery_plan`, `delivery_time`, `total_distance`, `deliver_by`, `pic_at_time`,`parcle_type`,`no_of_item`,`width`,`height`,`weight`,`length`,`delivery_status`,`payment_status`,`status`,`plat`,`plong`,`dlat`,`dlong`,`did`,`hname`,`hward`,`size`,`create_date`,`create_time`,`strub`,`state`,`post`,`dstrub`,`dstate`,`dpost`,`filter_status`) VALUES ('" . $data['uid'] . "','barcode_img','tract_number','" . $data['picupaddress'] . "','" . $data['dropoffaddress'] . "','" . $data['picupcontactname'] . "','" . $data['dropoffcontactname'] . "','" . $data['pickupunitnumber'] . "','" . $data['dropoffunitnumber'] . "','" . $data['pickupcnatctnumber'] . "','" . $data['dropoffcontactnumber'] . "','" . $data['picupcompany'] . "','" . $data['dropoffcompany'] . "','" . $file . "','" . $data['short_ins'] . "','" . $data['delivery_ins'] . "','','" . $data['noti_email'] . "','','','$date','" . $data['total_cost'] . "','" . $data['delivery_plan'] . "','" . $data['delivery_time'] . "','" . $data['total_distance'] . "','" . $data['deliver_by'] . "','" . $data['pic_at_time'] . "','" . $data['parcle_type'] . "','" . $data['no_of_item'] . "','" . $data['width'] . "','" . $data['height'] . "', '" . $data['weight'] . "','" . $data['length'] . "','pending','pending','1','" . $data['plat'] . "','" . $data['plong'] . "','" . $data['dlat'] . "','" . $data['dlong'] . "','0','','','','','','','','','','','','2')";
		 
		$sqlquery = mysql_query($query);
			$abc = mysql_insert_id();
		if($sqlquery)
		{
	
		$output['success'] = "1";
		$output['msg'] = "Parcel Added";
		$output['parcelid'] = $abc;
		$output['totalcost'] = $data['total_cost'];
		return $output;
	}
	else
	{
	    $output['success'] = "0";
		$output['msg'] = "unsuccessfully";	
		return $output;
	}
		}
}

} 
// barcode start code here
 
function gen_random($length=32)
	{
	    $final_rand='';
	    for($i=0;$i< $length;$i++)
	    {
	        $final_rand .= rand(0,9);
	 
	    }
	  
	    return $final_rand;
	}

	$filepath="";
	$text=$x;
	$size="20";
	$orientation="horizontal";
	$code_type=$x;
	$print=false;
	$SizeFactor=1 ;

function barcode( $filepath, $text, $size, $orientation,  $code_type, $print, $SizeFactor,$kk,$x ) {
	$code_string = "";
	// Translate the $text into barcode the correct $code_type
	if(in_array(strtolower($code_type),$kk))
	{
	
		$chksum = 104;
		// Must not change order of array elements as the checksum depends on the array's key to validate final code
		$code_array = array(" "=>"212222","!"=>"222122","\""=>"222221","#"=>"121223","$"=>"121322","%"=>"131222","&"=>"122213","'"=>"122312","("=>"132212",")"=>"221213","*"=>"221312","+"=>"231212",","=>"112232","-"=>"122132","."=>"122231","/"=>"113222","0"=>"123122","1"=>"123221","2"=>"223211","3"=>"221132","4"=>"221231","5"=>"213212","6"=>"223112","7"=>"312131","8"=>"311222","9"=>"321122",":"=>"321221",";"=>"312212","<"=>"322112","="=>"322211",">"=>"212123","?"=>"212321","@"=>"232121","A"=>"111323","B"=>"131123","C"=>"131321","D"=>"112313","E"=>"132113","F"=>"132311","G"=>"211313","H"=>"231113","I"=>"231311","J"=>"112133","K"=>"112331","L"=>"132131","M"=>"113123","N"=>"113321","O"=>"133121","P"=>"313121","Q"=>"211331","R"=>"231131","S"=>"213113","T"=>"213311","U"=>"213131","V"=>"311123","W"=>"311321","X"=>"331121","Y"=>"312113","Z"=>"312311","["=>"332111","\\"=>"314111","]"=>"221411","^"=>"431111","_"=>"111224","\`"=>"111422","a"=>"121124","b"=>"121421","c"=>"141122","d"=>"141221","e"=>"112214","f"=>"112412","g"=>"122114","h"=>"122411","i"=>"142112","j"=>"142211","k"=>"241211","l"=>"221114","m"=>"413111","n"=>"241112","o"=>"134111","p"=>"111242","q"=>"121142","r"=>"121241","s"=>"114212","t"=>"124112","u"=>"124211","v"=>"411212","w"=>"421112","x"=>"421211","y"=>"212141","z"=>"214121","{"=>"412121","|"=>"111143","}"=>"111341","~"=>"131141","DEL"=>"114113","FNC 3"=>"114311","FNC 2"=>"411113","SHIFT"=>"411311","CODE C"=>"113141","FNC 4"=>"114131","CODE A"=>"311141","FNC 1"=>"411131","Start A"=>"211412","Start B"=>"211214","Start C"=>"211232","Stop"=>"2331112");
		$code_keys = array_keys($code_array);
		$code_values = array_flip($code_keys);
		for ( $X = 1; $X <= strlen($text); $X++ ) {
			$activeKey = substr( $text, ($X-1), 1);
			$code_string .= $code_array[$activeKey];
			$chksum=($chksum + ($code_values[$activeKey] * $X));
		}
		$code_string .= $code_array[$code_keys[($chksum - (intval($chksum / 103) * 103))]];

		$code_string = "211214" . $code_string . "2331112";
	} elseif ( strtolower($code_type) == "code128a" ) {
		$chksum = 103;
		$text = strtoupper($text); // Code 128A doesn't support lower case
		// Must not change order of array elements as the checksum depends on the array's key to validate final code
		$code_array = array(" "=>"212222","!"=>"222122","\""=>"222221","#"=>"121223","$"=>"121322","%"=>"131222","&"=>"122213","'"=>"122312","("=>"132212",")"=>"221213","*"=>"221312","+"=>"231212",","=>"112232","-"=>"122132","."=>"122231","/"=>"113222","0"=>"123122","1"=>"123221","2"=>"223211","3"=>"221132","4"=>"221231","5"=>"213212","6"=>"223112","7"=>"312131","8"=>"311222","9"=>"321122",":"=>"321221",";"=>"312212","<"=>"322112","="=>"322211",">"=>"212123","?"=>"212321","@"=>"232121","A"=>"111323","B"=>"131123","C"=>"131321","D"=>"112313","E"=>"132113","F"=>"132311","G"=>"211313","H"=>"231113","I"=>"231311","J"=>"112133","K"=>"112331","L"=>"132131","M"=>"113123","N"=>"113321","O"=>"133121","P"=>"313121","Q"=>"211331","R"=>"231131","S"=>"213113","T"=>"213311","U"=>"213131","V"=>"311123","W"=>"311321","X"=>"331121","Y"=>"312113","Z"=>"312311","["=>"332111","\\"=>"314111","]"=>"221411","^"=>"431111","_"=>"111224","NUL"=>"111422","SOH"=>"121124","STX"=>"121421","ETX"=>"141122","EOT"=>"141221","ENQ"=>"112214","ACK"=>"112412","BEL"=>"122114","BS"=>"122411","HT"=>"142112","LF"=>"142211","VT"=>"241211","FF"=>"221114","CR"=>"413111","SO"=>"241112","SI"=>"134111","DLE"=>"111242","DC1"=>"121142","DC2"=>"121241","DC3"=>"114212","DC4"=>"124112","NAK"=>"124211","SYN"=>"411212","ETB"=>"421112","CAN"=>"421211","EM"=>"212141","SUB"=>"214121","ESC"=>"412121","FS"=>"111143","GS"=>"111341","RS"=>"131141","US"=>"114113","FNC 3"=>"114311","FNC 2"=>"411113","SHIFT"=>"411311","CODE C"=>"113141","CODE B"=>"114131","FNC 4"=>"311141","FNC 1"=>"411131","Start A"=>"211412","Start B"=>"211214","Start C"=>"211232","Stop"=>"2331112");
		$code_keys = array_keys($code_array);
		$code_values = array_flip($code_keys);
		for ($X = 1; $X <= strlen($text); $X++ ) {
			$activeKey = substr( $text, ($X-1), 1);
			$code_string .= $code_array[$activeKey];
			$chksum=($chksum + ($code_values[$activeKey] * $X));
		}
		$code_string .= $code_array[$code_keys[($chksum - (intval($chksum / 103) * 103))]];

		$code_string = "211412" . $code_string . "2331112";
	} elseif (strtolower($code_type) == "code39" ) {
		$code_array = array("0"=>"111221211","1"=>"211211112","2"=>"112211112","3"=>"212211111","4"=>"111221112","5"=>"211221111","6"=>"112221111","7"=>"111211212","8"=>"211211211","9"=>"112211211","A"=>"211112112","B"=>"112112112","C"=>"212112111","D"=>"111122112","E"=>"211122111","F"=>"112122111","G"=>"111112212","H"=>"211112211","I"=>"112112211","J"=>"111122211","K"=>"211111122","L"=>"112111122","M"=>"212111121","N"=>"111121122","O"=>"211121121","P"=>"112121121","Q"=>"111111222","R"=>"211111221","S"=>"112111221","T"=>"111121221","U"=>"221111112","V"=>"122111112","W"=>"222111111","X"=>"121121112","Y"=>"221121111","Z"=>"122121111","-"=>"121111212","."=>"221111211"," "=>"122111211","$"=>"121212111","/"=>"121211121","+"=>"121112121","%"=>"111212121","*"=>"121121211");

		// Convert to uppercase
		 $upper_text = strtoupper($text);

		for ( $X = 1; $X<=strlen($upper_text); $X++ ) {
			$code_string .= $code_array[substr( $upper_text, ($X-1), 1)] . "1";
		}

		$code_string = "1211212111" . $code_string . "121121211";
	} elseif ( strtolower($code_type) == "code25" ) {
		$code_array1 = array("1","2","3","4","5","6","7","8","9","0");
		$code_array2 = array("3-1-1-1-3","1-3-1-1-3","3-3-1-1-1","1-1-3-1-3","3-1-3-1-1","1-3-3-1-1","1-1-1-3-3","3-1-1-3-1","1-3-1-3-1","1-1-3-3-1");

		for ( $X = 1; $X <= strlen($text); $X++ ) {
			for ( $Y = 0; $Y < count($code_array1); $Y++ ) {
				if ( substr($text, ($X-1), 1) == $code_array1[$Y] )
					$temp[$X] = $code_array2[$Y];
			}
		}

		for ( $X=1; $X<=strlen($text); $X+=2 ) {
			if ( isset($temp[$X]) && isset($temp[($X + 1)]) ) {
				$temp1 = explode( "-", $temp[$X] );
				$temp2 = explode( "-", $temp[($X + 1)] );
				for ( $Y = 0; $Y < count($temp1); $Y++ )
					$code_string .= $temp1[$Y] . $temp2[$Y];
			}
		}

		$code_string = "1111" . $code_string . "311";
	} elseif (strtolower($code_type) == "codabar" ) {
		$code_array1 = array("1","2","3","4","5","6","7","8","9","0","-","$",":","/",".","+","A","B","C","D");
		$code_array2 = array("1111221","1112112","2211111","1121121","2111121","1211112","1211211","1221111","2112111","1111122","1112211","1122111","2111212","2121112","2121211","1121212","1122121","1212112","1112122","1112221");

		// Convert to uppercase
		 $upper_text = strtoupper($text);

		for ( $X = 1; $X<=strlen($upper_text); $X++ ) {
			for ( $Y = 0; $Y<count($code_array1); $Y++ ) {
				if ( substr($upper_text, ($X-1), 1) == $code_array1[$Y] )
					$code_string .= $code_array2[$Y] . "1";
			}
		}
		$code_string = "11221211" . $code_string . "1122121";
	}

	// Pad the edges of the barcode
	$code_length = 20;
	if ($print) {
		$text_height = 30;

	} else {
		$text_height = 0;
	}

	for ( $i=1; $i <= strlen($code_string); $i++ ){
		$code_length = $code_length + (integer)(substr($code_string,($i-1),1));
        }

	if (strtolower($orientation) == "horizontal" ) {
		$img_width = $code_length*$SizeFactor;
		$img_height = $size;
	} else {
		$img_width = $size;
		$img_height = $code_length*$SizeFactor;
	}

	$barcode_images = imagecreate($img_width, $img_height + $text_height);
	$black = imagecolorallocate ($barcode_images, 0, 0, 0);
	$white = imagecolorallocate ($barcode_images, 255, 255, 255);

	imagefill( $barcode_images, 0, 0, $white );
	if($print) {

		imagestring($barcode_images, 5, 31, $img_height, $code_type, $black);

	}

	$location = 10;
	for ($position = 1 ; $position <= strlen($code_string); $position++ ) {
		$cur_size = $location + ( substr($code_string, ($position-1), 1) );
		if (strtolower($orientation) == "horizontal" )
			imagefilledrectangle( $barcode_images, $location*$SizeFactor, 0, $cur_size*$SizeFactor, $img_height, ($position % 2 == 0 ? $white : $black) );
		else
			imagefilledrectangle($barcode_images, 0, $location*$SizeFactor, $img_width, $cur_size*$SizeFactor, ($position % 2 == 0 ? $white : $black) );
		$location = $cur_size;
	}
	$tbn='.';

	// Draw barcode to the screen or save in a file
	if ($filepath=="" ) {
		$new_img = 'MTXP'.$x.$tbn.'png';
		
		imagepng($barcode_images,'img/'.$new_img);
		
		if (isset($_GET['parcelid'])) {
		move_uploaded_file($barcode_images,$filepath);
	
		$images_sql = "UPDATE `moto_parcle_orders` SET `barcode_img` = '".$new_img."' WHERE `id` = '".$_GET['parcelid']."'";
		mysql_query($images_sql);
		$barcode_images  = '';
		return $barcode_images;
	   }
	} else {

		imagepng($barcode_images,$filepath);
		imagedestroy($barcode_images);	
      
	}
 }
 // barcode end code here 
function UpdateParcelPayment($data)
{
	$output = array();
	if ($data['parcelid'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else
	{ 


	$cjk=gen_random(7);
		//die();
		$x=$cjk;
		$r=$cjk;
		$u=',';
		$t=$cjk.'b';
		$rv='"';
		$kk=$r.",".$t;
		$kk=explode(",", $kk);

		// For demonstration purposes, get pararameters that are passed in through $_GET or set to the default value
		$filepath = (isset($_GET["filepath"])?$_GET["filepath"]:"");
		$text = (isset($_GET["text"])?$_GET["text"]:$x);
		$size = (isset($_GET["size"])?$_GET["size"]:"20");
		$orientation = (isset($_GET["orientation"])?$_GET["orientation"]:"horizontal");
		$code_type = (isset($_GET["codetype"])?$_GET["codetype"]:$x);
		$print = (isset($_GET["print"])&&$_GET["print"]=='true'?true:true);
		$sizefactor = (isset($_GET["sizefactor"])?$_GET["sizefactor"]:"2");

		// This function call can be copied into your project and can be made from anywhere in your code
		$barcode_images = barcode($filepath, $text, $size, $orientation, $code_type, $print, $sizefactor,$kk,$x);

 

        $tract_number = 'p'.time();
		$query = "UPDATE `moto_parcle_orders` SET payment_method='" . $data['payment_method'] . "' , tract_number ='".$tract_number."' , payment_status='completed',status=1 where id='".$data['parcelid']."'";
		$sqlquery = mysql_query($query);
		if($sqlquery)
		{
		$abc = mysql_insert_id();
		$sql  = "SELECT * FROM `moto_parcle_orders` WHERE `id` = '".$data['parcelid']."'";
      
        $sqlres = mysql_query($sql);
		   $sqlsu = "SELECT * FROM `moto_users` where `userid`='".$data['uid']."' ";
	   $sqlqueryyu=mysql_query($sqlsu);
		  $rowsu=mysql_fetch_array($sqlqueryyu);
		  	$u=$rowsu['username'];
		  $dsql1 = "SELECT * FROM `moto_runner` ";
		   $dsqlquery1=mysql_query($dsql1);
		   while($rowd=mysql_fetch_array($dsqlquery1))
		   { 
		  //$divername= $rowd['firstname'].' ' .$rowd['lastname'];
		  //$deviceid='d313707d9ac216d814c46e3d5c778c2bd1e8bbfac872fa227128e8b332857077';
		   $deviceid=$rowd['deviceid']; 
			 $device_type=$rowd['device_type'];
			if($deviceid != NULL)
			{
				$message1 = 'new parcel'; 
				$message2 = "New Parcel Posted"; 
				if($device_type == 'Android')
				{	
					$registatoin_ids = array($deviceid);
					$message123 = array("msg" => $message1,"notification" => $message2,"notitype" =>'new_parcel') ;
				    $result1=sendMessagedriver($message123,$registatoin_ids); 
				}	
				else if($device_type == 'ios')
				{	
					$registatoin_ids = array($deviceid);
					$message123 = array("msg" => $message1,"notification" => $message2,"notitype" =>'new_parcel') ;
					 $result1=sendnotificationiosDriver($registatoin_ids,$message123);  
				}
			
			}
		   }
        $resultrow = mysql_fetch_assoc($sqlres);

        $apikey = '3839e2ea-348c-48d9-b438-3bf02350fd3b';
		$value = '<style>
body
{
margin:0px;
padding:0px;
}
</style>
<table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#FAFAFA" align="center" height="100%" style="padding:0px;" id="bodyTable">
<tbody><tr>
<td valign="top">
<table width="100%" align="center"  cellspacing="0" cellpadding="0" border="0"  style="max-width:600px; border:1px solid #000; font-family: Arial, Helvetica,">

<!-- BEGIN GREETING // -->
<tbody>
<!-- END GREETING // -->

<!-- BEGIN TEMPLATE LOGO BOX // -->
<tr>
<td valign="top" align="center" style=" max-width:600px;font-size:10px; line-height:125%; font-family: Arial,Helvetica,sans-serif; background-color:#ffffff; " id="bodyCellTop">
<table width="600" cellspacing="0" cellpadding="0" border="0" style=" max-width:100%;" id="templateContainer">
<tbody><tr>
<td width="600" valign="top" height="70" style="background:#FEFEFE; line-height: 125%; text-align:center; padding-top:0px; padding-bottom:5px;" class="topbar topbar-center">

<img width="200" mc:edit="logo_image" mc:label="logo_image" class="columnImage" style="width:200px !important; height:120x;" src="https://infograins.com/INFODE/pankaj/motoxpress/logo.png" editable="">
</td>

</tr>
<tr>
<td width="600" valign="top" height="50" style="background:#FEFEFE; line-height: 125%; text-align:center; padding-top:15px; padding-bottom:15px; color:#E20500" class="topbar topbar-center">                                
<b>Dispatch date: '.$resultrow['pic_at_time'].'</b>
</td>
</tr>
<tr>
<td width="600" valign="top" height="30" style="background:#E20500; line-height: 125%; text-align:center; padding-top:10px; padding-bottom:8px; color:; font-weight:bold" class="topbar topbar-center">
'.$resultrow['parcle_type'].'
</td>
</tr></tbody></table>
</td>
</tr>        
<!-- END TEMPLATE LOGO BOX // -->

<!-- BEGIN TEMPLATE HEADING IMAGE - Full 100% Width // -->

<!-- END TEMPLATE HEADING IMAGE - Full 100% Width // -->

<tr> 
<td valign="top" bgcolor="#FFFFFF" align="center" style=" background-color:#FFFFFF; font-family: Arial, Helvetica, sans-serif; color:#505050; font-size:14px;" id="bodyCell">
<repeater>	
</repeater><repeater>
</repeater><repeater>
</repeater>
<table cellspacing="0" cellpadding="0" border="0" style="width:600px; background:#f1f1f1; ;border-collapse:collapse;">

<!-- // Start Line with the Title  -->
<tbody><tr class="titleline">
<td width="100%" valign="middle" align="left" height="21" style=" padding:10px; padding-top:30px; padding-bottom:0px;">
<table width="100%" cellspacing="0" cellpadding="0" border="0" height="1">
<tbody>
<tr>
<td valign="top" style="width:100px; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-align:right; padding-right:30px; text-transform:uppercase">
To:
</td>
<td valign="top" style="width:300px; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-transform:uppercase">
'.$resultrow['dropoffaddress'].'
</td>
</tr>
<tr>
<td colspan="2" height="2px;"></td>
</tr>
<tr>
<td valign="top" style="width:100px; padding-bottom:3px; color: #383838; font-size: 13px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold;  text-align:right; padding-right:30px;">
Contact:
</td>
<td valign="top" style="width:300px; padding-bottom:3px; color: #383838; font-size: 13px; font-weight:normal; font-family: Arial, Helvetica;  text-transform:uppercase; font-weight:bold; ">
'.$resultrow['picupcontactname'].'
</td>
</tr>
<tr>
<td colspan="2" height="2px;"></td>
</tr>
<tr>
<td valign="top" style="width:100px; padding-bottom:3px; color: #383838; font-size: 13px; font-weight:normal; font-family: Arial, Helvetica;  text-align:right; padding-right:30px; font-weight:bold; ">

phone number:

</td>
<td valign="top" style="width:300px; padding-bottom:3px; color: #383838; font-size: 13px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; ">
'.$resultrow['dropoffcontactnumber'].'
</td>
</tr>

<tr>
<td colspan="2" height="2px;"></td>
</tr>
<tr>
<td valign="top" style="width:100px; padding-bottom:3px; color: #383838; font-size: 13px; font-weight:normal; font-family: Arial, Helvetica;  text-align:right; padding-right:30px;font-weight:bold; ">
Special Inst:
</td>
<td valign="top" style="width:300px; padding-bottom:3px; color: #383838; font-size: 12px; font-weight:normal; font-family: Arial, Helvetica;  ">
Authority to leave at front door
</td>
</tr>
<tr>
<td colspan="2" height="30px;"></td>
</tr>

<tr>
<td valign="top" style="width:100px; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-align:right; padding-right:30px; text-transform:uppercase">

From:

</td>
<td valign="top" style="width:300px; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-transform:uppercase">
'.$resultrow['picupaddress'].'
</td>
</tr>
<tr>
<td colspan="2" height="2px;"></td>
</tr>
<tr>
<td valign="top" style="width:100px; padding-bottom:3px; color: #383838; font-size: 13px; font-weight:normal; font-family: Arial, Helvetica;  text-align:right; padding-right:30px; font-weight:bold; ">
phone number:
</td>
<td valign="top" style="width:300px; padding-bottom:3px; color: #383838; font-size: 13px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; ">
'.$resultrow['pickupcnatctnumber'].'</td>
</tr>
<tr>
<td colspan="2" height="2px;"></td>
</tr>
<tr>
<td valign="top" style="width:100px; padding-bottom:3px; color: #383838; font-size: 12px; font-weight:normal; font-family: Arial, Helvetica;  text-align:right; padding-right:30px;">

Change Acc: 

</td>
<td valign="top" style="width:300px; padding-bottom:3px; color: #383838; font-size: 12px; font-weight:normal; font-family: Arial, Helvetica;  ">

603472

</td>
</tr>
<tr>
<td colspan="2" height="30px;"></td>
</tr>

<tr>
<td valign="top" style="width:100px; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-align:right; padding-right:30px; text-transform:uppercase">
</td>
<td valign="top" style="width:300px; padding-bottom:3px; color: #383838; font-size: 16px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-transform:uppercase">
Total Weight
</td>
</tr>
<tr>
<td colspan="2" height="5px;"></td>
</tr>
<tr>
<td valign="top" style="width:100px; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-align:right; padding-right:30px; text-transform:uppercase">

Total Weight :
</td>
<td valign="top" style="width:300px; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-transform:uppercase">
'.$resultrow['weight'].' 
</td>
</tr>
<tr>
<td colspan="2" height="5px;"></td>
</tr>
<tr>
<td valign="top" style="width:100px; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-align:right; padding-right:30px; text-transform:uppercase">
Size :
</td>
<td valign="top" style="width:300px; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-transform:uppercase">
'.$resultrow['length'].'X'.$resultrow['width'].'X'.$resultrow['height'].'                                        
</td>
</tr>
<tr>
<td colspan="2" align="center" style="padding:20px 0 0; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  ">
<span>
 <br>
<img width="200" mc:edit="logo_image" mc:label="logo_image" class="columnImage" style="width:200px !important; height:150x;" src="http://infograins.com.208-91-199-7.md-plesk-web2.webhostbox.net/INFO01/motoxpress/api/img/'.$resultrow["barcode_img"].'" editable="">
</td>
</tr>
<tr>
<td colspan="2" height="5px;"></td>
</tr>
<tr>
<td valign="top" style="width:100px; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-align:right; padding-right:30px;">
Declaration by :
</td>
<td valign="top" style="width:300px; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica;  font-weight:bold; text-transform:uppercase">'.$resultrow['deliver_by'].'</td>
</tr>
<td colspan="2" align="left" style="padding:10px 20px; color: #383838; font-size: 12px; font-weight:normal; font-family: Arial, Helvetica;  ">
<span><b>Warning</b>: On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue;</span> <br>
</td>
</tr>
<tr>
</tbody></table>
</td>
</tr>
<!-- // End Line with the Title  -->

<!-- BEGIN Text 580px // -->


<!-- // END Text 580px  -->

<!-- BEGIN Text 580px // -->
<!-- // END Text 580px  -->

</tbody></table>
</td> 
</tr>   
<tr>
<td valign="top" align="center" style="background-color:#1F1F1F; " class="bodyCellFooterSecond" id="bodyCellFooter">
<table width="600" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:600px;" id="templateContainer">
<tbody><tr>
<td valign="top" mc:edit="footer_content02" style="text-align:left; padding:10px; color:#b2b2b2; font-family: Arial, Helvetica, sans-serif; font-size:10px; line-height:150%;" class="footerContent2">
<multiline label="">  
&copy; Copyright 2016 MotoXpress. All Rights Reserved.
</multiline><br>
<!-- <a style="color: #888888;" href="*|UPDATE_PROFILE|*"><preferences>update subscription preferences</preferences></a>  -->
</td>
</tr>
</tbody></table>
</td>
</tr>
<!-- end footer dark part -->
</tbody></table>
</td>
</tr>
</tbody></table>'; // can aso be a url, starting 
			$result = file_get_contents("http://api.html2pdfrocket.com/pdf?apikey=" . urlencode($apikey) . "&value=" . urlencode($value));

			$myfile = time().'bill'.'.pdf';
			$Pdfcontent = file_put_contents('PDFFolder/'.$myfile, $result);
			$path = 'PDFFolder/'.$myfile;

			$content = file_get_contents($path);
			$content = chunk_split(base64_encode($content));
			//header("Content-Type: application/octet-stream");
			$file ='PDFFolder/'.$myfile;
			//header("Content-Disposition: attachment; filename=".urlencode($file));   
			//header("Content-Type: application/octet-stream");
			
            $uid = md5(uniqid(time()));
            $from_name = 'Order Details';
			$from_mail = 'info@infograins.com';
			$subject ="Parcel delivery details By motoxpress..!";


			$mailto = $resultrow['noti_email'];

			$message = '<style>
body
{
	margin:0px;
	padding:0px;
}
</style>
<table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#FAFAFA" align="center" height="100%" style="padding:0px;" id="bodyTable">
            <tbody><tr>
            <td valign="top">
            <table width="100%" align="center"  cellspacing="0" cellpadding="0" border="0"  style="max-width:600px; border:1px solid #000; font-family: Arial, Helvetica,">
            
            	<!-- BEGIN GREETING // -->
                <tbody>
                <!-- END GREETING // -->
            
            	<!-- BEGIN TEMPLATE LOGO BOX // -->
                <tr>
               	  <td valign="top" align="center" style=" max-width:600px;font-size:10px; line-height:125%; font-family: Arial,Helvetica,sans-serif; background-color:#ffffff; " id="bodyCellTop">
                    	<table width="600" cellspacing="0" cellpadding="0" border="0" style=" max-width:100%;" id="templateContainer">
                        	<tbody><tr>
                            	<td width="600" valign="top" height="70" style="background:#FEFEFE; line-height: 125%; text-align:center; padding-top:0px; padding-bottom:5px;" class="topbar topbar-center">
                                
                                		<img width="200" mc:edit="logo_image" mc:label="logo_image" class="columnImage" style="width:200px !important; height:120x;" src="https://infograins.com/INFODE/pankaj/motoxpress/logo.png" editable="">
                                </td>
                              	
                            </tr>
                            
                            <tr>
                            <td width="600" valign="top" height="30" style="background:#1F1F1F; line-height: 125%; text-align:left; padding-top:10px; padding-bottom:8px; color:#fff; font-size:15px; padding-left:10px; padding-right:10px; font-weight:500">
                             Your delivery to DONALDSON MECHNICAL has been booked

                                </td>
                            </tr></tbody></table>
                    </td>
                </tr>        
                <!-- END TEMPLATE LOGO BOX // -->
                
                <!-- BEGIN TEMPLATE HEADING IMAGE - Full 100% Width // -->
                
				<!-- END TEMPLATE HEADING IMAGE - Full 100% Width // -->
                
                <tr>
                	<td valign="top" bgcolor="#FFFFFF" align="center" style=" background-color:#FFFFFF; font-family: Arial, Helvetica, sans-serif; color:#505050; font-size:14px;" id="bodyCell">
                    	<repeater>	
                            </repeater><repeater>
                            </repeater><repeater>
                            </repeater>
                            <table cellspacing="0" cellpadding="0" border="0" style="width:600px; background:#f1f1f1; ;border-collapse:collapse;">
                        
                            <!-- // Start Line with the Title  -->
                            <tbody><tr class="titleline">
                            	<td width="100%" valign="middle" align="left" height="21" style=" padding:10px; padding-top:30px; padding-bottom:0px;">
                                	<table width="100%" cellspacing="0" cellpadding="0" border="0" height="1">
                                    	<tbody>
                                        <tr>
                                        	<td valign="top" colspan="2" style="width:; padding-bottom:3px; color: #383838; font-size: 16px; font-weight:normal; font-family: Arial, Helvetica; padding-right:30px;">
	                                           Hello, <span style="text-transform:uppercase; font-weight:bold; font-size:15px; color:#E20500"> '.$resultrow['dropoffcontactname'].'</span>
                                        	</td>
                                        	
                                        </tr>
                                        <tr>
                                        	<td colspan="2" height="10px"></td>
                                        </tr>
                                        <tr>
                                        	<td valign="top" colspan="2" style="width:; padding-bottom:3px; color: #383838; font-size: 13px; font-weight:normal; font-family: Arial, Helvetica; padding-right:30px;">
	                                          On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue;
                                        	</td>
                                        	
                                        </tr>
                                        <tr>
                                        	<td colspan="2" height="10px"></td>
                                        </tr>
                                        <tr>
                                        	<td valign="top" colspan="2" style="width:; padding-bottom:3px; color: #383838; font-size: 13px; font-weight:normal; font-family: Arial, Helvetica; padding-right:30px;">
	                                          At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.
                                        	</td>
                                        	
                                        </tr>
                                        <tr>
                                        	<td colspan="2" height="8"></td>
                                        </tr>
                                        <tr>
                                        	<td valign="top" colspan="2" style="width:; padding-bottom:3px; color: #383838; font-size: 13px; font-weight:normal; font-family: Arial, Helvetica; padding-right:30px;">
	                                          At vero eos et accusamus et iusto odio dignissimos
                                        	</td>
                                        	
                                        </tr> 
                                        <tr>
                                        	<td colspan="2" height="8"></td>
                                        </tr>
                                        <tr>
                                        	<td valign="top" colspan="2" style="width:; padding-bottom:3px; color: #383838; font-size: 16px; font-weight:normal; font-family: Arial, Helvetica; font-weight:bold; color:#E20500; padding-right:30px;">
	                                         Delivery Details
                                        	</td>
                                            
                                        </tr>
                                        <tr>
                                        	<td colspan="2" height="8"></td>
                                        </tr>
                                        <tr style="background:#fff; border:1px solid #e1e1e1">
                                        
                                        	<td valign="top" style="width:50%; padding-bottom:3px; color: #383838; font-size: 14px; font-weight:normal; font-family: Arial, Helvetica; padding:10px;">
                                            	<p style="margin:0px;"><b>Courier:</b></p>
                                                <p style="margin:0px;">TollPriority Overnight</p>
                                                <br />
                                                <p style="margin:0px;"><b>Transdirect Reference:</b></p>
                                                <p style="margin:0px;">17369845</p>
                                                <br />
                                                <p style="margin:0px;"><b>Courier Reference:</b></p>
                                                <p style="margin:0px;">ARL17369845</p>
                                                <br />
                                                <p style="margin:0px;"><b>ETA:</b></p>
                                                <p style="margin:0px;">'.$resultrow['cdate'].'</p>
                                            </td>
                                            
                                            
                                            <td valign="top" style="width:50%; padding-bottom:3px; color: #383838; font-size: 12px; font-weight:normal; font-family: Arial, Helvetica;  padding:10px;">
                                            	<p style="margin:0px; font-size:14px"><b>Pickup Address:</b></p>
                                                <p style="margin:0px; text-transform:uppercase">'.$resultrow['picupaddress'].'<br />  
                                                <br /> <br /> 
                                            	<p style="margin:0px; font-size:14px"><b>Delivery  Address:</b></p>
                                                <p style="margin:0px; text-transform:uppercase">'.$resultrow['dropoffaddress'].'<br />  
                                                
                                                </p>
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                        	<td colspan="2" height="20"></td>
                                        </tr>
                                      
                                      
                                        <tr>
                                        	<td colspan="2" style="color: #383838; text-align:center; font-weight:normal; font-family: Arial, Helvetica;"> 
                                            <a href="" style="color:#E20500; border:1px solid #E20500; padding:6px 10px; text-decoration:none; 
                                            display:inline-block; border-radius:30px; font-size:13px; font-weight:bold; text-transform:uppercase">TRACK CONsignment arl '.$resultrow['tract_number'].'</a></td>
                                        </tr>
                                        
                                        
                                        <tr>
                                        	<td colspan="2" height="20"></td>
                                        </tr>
                                      
                                      
                                      
                                        
                                        
                                        <tr>
                                        
                                        
                                        
                                    </tbody></table>
                                </td>
                            </tr>
                            <!-- // End Line with the Title  -->
                            
                            <!-- BEGIN Text 580px // -->
                        	
                            
                            <!-- // END Text 580px  -->
                            
                            <!-- BEGIN Text 580px // -->
                        		
                            
                            
                            <!-- // END Text 580px  -->
                          
                        </tbody></table>
                    </td> 
              </tr>   
              <tr>
              	<td valign="top" align="center" style="background-color:#1F1F1F; " class="bodyCellFooterSecond" id="bodyCellFooter">
                	<table width="600" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:600px;" id="templateContainer">
                    	<tbody><tr>
                        	<td valign="top" mc:edit="footer_content02" style="text-align:left; padding:10px; color:#b2b2b2; font-family: Arial, Helvetica, sans-serif; font-size:10px; line-height:150%;" class="footerContent2">
                                                 <multiline label="">  
                                                 	

&copy; Copyright 2016 MotoXpress. All Rights Reserved.
</multiline><br>
                                            	
                                                
                                               
                                              <!-- <a style="color: #888888;" href="*|UPDATE_PROFILE|*"><preferences>update subscription preferences</preferences></a>  -->
                             </td>
                         </tr>
					 </tbody></table>
                  </td>
              </tr>
              <!-- end footer dark part -->
            </tbody></table>
            </td>
            </tr>
           </tbody></table>';


			$header = "From: ".$from_name." <".$from_mail.">\r\n";
			$header .= "MIME-Version: 1.0\r\n";
			$header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";

			$nmessage = "--".$uid."\r\n";
			$nmessage .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$nmessage .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
			$nmessage .= $message."\r\n\r\n";
			$nmessage .= "--".$uid."\r\n";


			$nmessage .= "Content-Type: application/octet-stream; name=\"".$myfile."\"\r\n";
			$nmessage .= "Content-Transfer-Encoding: base64\r\n";
			$nmessage .= "Content-Disposition: attachment; filename=\"".$myfile."\"\r\n\r\n";
			$nmessage .= $content."\r\n\r\n";
			$nmessage .= "--".$uid."--";

		if (mail($mailto, $subject, $nmessage, $header)) {
	   
	    $output['success'] = "1";
		$output['msg'] = "Parcel updated and mail send!";
		return $output;
	} 
	else 
	{
	     $output['success'] = "0";
		$output['msg'] = "Parcel updated and not send!";
		return $output;
	}
  
		$output['success'] = "1";
		$output['msg'] = "Parcel updated";
		return $output;
	}
  }
}
function GetRunnerProfile($data)
{
	$output = array();
	if ($data['rid'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	} 
	else
	{
		$sql = "SELECT * FROM `moto_runner` WHERE `rid` = '" . $data['rid'] . "'";
		$sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			
			while ($row = mysql_fetch_array($sqlquery))
			{
				$sqlarray['id'] = $row['rid'];
				$sqlarray['username'] = $row['username'];
				$sqlarray['email'] = $row['email'];
				$sqlarray['mobile'] = $row['mobile'];
				$sqlarray['password'] = $row['password'];
				$sqlarray['profile_image'] = RUNNER_IMG.$row['profile_image'];
				

				
			}

			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['Detail'] = $sqlarray;
			return $output;
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "No rid Found";
			return $output;
		}
	}
}
function GetUserProfile($data)
{
	$output = array();
	if($data['userid'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else
	{
		$sql = "SELECT * FROM `moto_users` WHERE `userid` = '" . $data['userid'] . "'";
		$sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			
			while ($row = mysql_fetch_array($sqlquery))
			{
				$sqlarray['id'] = $row['userid'];
				$sqlarray['fullname'] = $row['fullname'];
				$sqlarray['email'] = $row['email'];
				$sqlarray['mobile'] = $row['mobile'];
				$sqlarray['password'] = base64_decode($row['password']);
				
				
			}

			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['Detail'] = $sqlarray;
			return $output;
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "No user id Found";
			return $output;
		}
	}
}
function GetParcelDetail($data)
{
	$output = array();
	if ($data['parcelid'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else
	{
		$sql = "SELECT * FROM `moto_parcle_orders` WHERE `id` = '" . $data['parcelid'] . "'";
		$sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			$i = 0;
			while ($row = mysql_fetch_array($sqlquery))
			{
				$sqlarray[$i]['id'] = $row['id'];
				$sqlarray[$i]['picupaddress'] = $row['picupaddress'];
				$sqlarray[$i]['dropoffaddress'] = $row['dropoffaddress'];
				$sqlarray[$i]['picupcontactname'] = $row['picupcontactname'];
				$sqlarray[$i]['dropoffcontactname'] = $row['dropoffcontactname'];
				$sqlarray[$i]['pickupunitnumber'] = $row['pickupunitnumber'];
				$sqlarray[$i]['dropoffunitnumber'] = $row['dropoffunitnumber'];
				$sqlarray[$i]['pickupcnatctnumber'] = $row['pickupcnatctnumber'];
				$sqlarray[$i]['dropoffcontactnumber'] = $row['dropoffcontactnumber'];
				$sqlarray[$i]['picupcompany'] = $row['picupcompany'];
				$sqlarray[$i]['dropoffcompany'] = $row['dropoffcompany'];
				$sqlarray[$i]['short_ins'] = $row['short_ins'];
				$sqlarray[$i]['delivery_ins'] = $row['delivery_ins'];
				$sqlarray[$i]['noti_email'] = $row['noti_email'];
				$sqlarray[$i]['total_cost'] = $row['total_cost'];
				$sqlarray[$i]['delivery_time'] = $row['delivery_time'];
				$sqlarray[$i]['total_distance'] = $row['total_distance'];
				$sqlarray[$i]['deliver_by'] = $row['deliver_by'];
				$sqlarray[$i]['pic_at_time'] = $row['pic_at_time'];
				$sqlarray[$i]['parcle_type'] = $row['parcle_type'];
				$sqlarray[$i]['no_of_item'] = $row['no_of_item'];
				$sqlarray[$i]['width'] = $row['width'];
				$sqlarray[$i]['height'] = $row['height'];
				$sqlarray[$i]['weight'] = $row['weight'];
				$sqlarray[$i]['length'] = $row['length'];
				$sqlarray[$i]['plat'] = $row['plat'];
				$sqlarray[$i]['plong'] = $row['plong'];
				$sqlarray[$i]['dlat'] = $row['dlat'];
				$sqlarray[$i]['dlong'] = $row['dlong'];
				$photo=explode(",",$row['photo']);
				if($photo[0]!='')
				{
				for($k=0;$k < count($photo); $k++)
				{
					$sqlarray[$i]['photo'.$k.''] = "https://infograins.com/INFO01/motoxpress/api/uploads/".$photo[$k];
				} 
				}
				$sqlarray[$i]['delivery_status'] = $row['delivery_status'];
				$sql1 = "SELECT * FROM `moto_users` WHERE `userid` = '" . $row['uid'] . "'";
		        $sqlquery1 = mysql_query($sql1);
				$row1 = mysql_fetch_array($sqlquery1);
				$sqlarray[$i]['userid'] = $row1['userid'];
				$sqlarray[$i]['fullname'] = $row1['fullname'];
				$sqlarray[$i]['mobile'] = $row1['mobile'];
				$sql1 = "SELECT * FROM `moto_delivery_price` WHERE `id` = '" . $row['delivery_plan'] . "'";
		        $sqlquery1 = mysql_query($sql1);
				$row1 = mysql_fetch_array($sqlquery1);
				$sqlarray[$i]['planid'] = $row1['id'];
				$sqlarray[$i]['planname'] = $row1['name'];
				$sqlarray[$i]['planflatrate'] = $row1['flatrate'];
				$sqlarray[$i]['plankmrate'] = $row1['kmrate'];
				$sqlarray[$i]['plancolor'] = $row1['color'];
				$i++;
			}

			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['Detail'] = $sqlarray;
			return $output;
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "No Parcel Found";
			return $output;
		}
	}
}
function GetAllParcel($data)
{
	$output = array();
	
		$sql = "SELECT * FROM `moto_parcle_orders` WHERE `status` = 1 and delivery_status='pending' and did=0 order by id DESC";
		$sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			$i = 0;
			while ($row = mysql_fetch_array($sqlquery))
			{
				$sqlarray[$i]['parcelid']=$row['id'];
				$sqlarray[$i]['picupaddress']=$row['picupaddress'];
				$sqlarray[$i]['dropoffaddress']=$row['dropoffaddress'];
				$sqlarray[$i]['picupcontactname']=$row['picupcontactname'];
				$sqlarray[$i]['dropoffcontactname']=$row['dropoffcontactname'];
				$sqlarray[$i]['pickupunitnumber']=$row['pickupunitnumber'];
				$sqlarray[$i]['dropoffunitnumber']=$row['dropoffunitnumber'];
				$sqlarray[$i]['pickupcnatctnumber']=$row['pickupcnatctnumber'];
				$sqlarray[$i]['dropoffcontactnumber']=$row['dropoffcontactnumber'];
				$sqlarray[$i]['picupcompany']=$row['picupcompany'];
				$sqlarray[$i]['dropoffcompany']=$row['dropoffcompany'];
				$sqlarray[$i]['photo']=$row['photo'];
				$sqlarray[$i]['short_ins']=$row['short_ins'];
				$sqlarray[$i]['delivery_ins']=$row['delivery_ins'];
				$sqlarray[$i]['noti_email']=$row['noti_email'];
				$sqlarray[$i]['payment_method']=$row['payment_method'];
				$sqlarray[$i]['photo']=$row['photo'];
				$sqlarray[$i]['short_ins']=$row['short_ins'];
				$sqlarray[$i]['delivery_ins']=$row['delivery_ins'];
				$sqlarray[$i]['noti_email']=$row['noti_email'];
				$sqlarray[$i]['cdate']=$row['cdate'];
				$sqlarray[$i]['total_cost']=$row['total_cost'];
				$sqlarray[$i]['delivery_plan']=$row['delivery_plan'];
				$sqlarray[$i]['delivery_time']=$row['delivery_time'];
				$sqlarray[$i]['total_distance']=$row['total_distance'];
				$sqlarray[$i]['deliver_by']=$row['deliver_by'];
				$sqlarray[$i]['total_cost']=$row['total_cost'];
				$sqlarray[$i]['pic_at_time']=$row['pic_at_time'];
				$sqlarray[$i]['delivery_time']=$row['delivery_time'];
				$sqlarray[$i]['total_distance']=$row['total_distance'];
				$sqlarray[$i]['parcle_type']=$row['parcle_type'];
				$sqlarray[$i]['no_of_item']=$row['no_of_item'];
				$sqlarray[$i]['width']=$row['width'];
				$sqlarray[$i]['height']=$row['height'];
				$sqlarray[$i]['weight']=$row['weight'];
				$sqlarray[$i]['length']=$row['length'];
				$sqlarray[$i]['delivery_status']=$row['delivery_status'];
				$sqlarray[$i]['payment_status']=$row['payment_status'];
				$sqlarray[$i]['status']=$row['status'];
				$sqlarray[$i]['plat']=$row['plat'];
				$sqlarray[$i]['plong']=$row['plong'];
				$sqlarray[$i]['dlat']=$row['dlat'];
				$sqlarray[$i]['dlong']=$row['dlong'];
				$sqlarray[$i]['did']=$row['did'];
				$photo=explode(",",$row['photo']);
				if($photo[0]!='')
				{
				for($k=0;$k < count($photo); $k++)
				{
					$sqlarray[$i]['photo'.$k.''] = "https://infograins.com/INFO01/motoxpress/api/uploads/".$photo[$k];
				} 
				}
				$sqlarray[$i]['delivery_status'] = $row['delivery_status'];
				$sql1 = "SELECT * FROM `moto_users` WHERE `userid` = '" . $row['uid'] . "'";
		        $sqlquery1 = mysql_query($sql1);
				$row1 = mysql_fetch_array($sqlquery1);
				$sqlarray[$i]['userid'] = $row1['userid'];
				$sqlarray[$i]['userfullname'] = $row1['fullname'];
				$sqlarray[$i]['usermobile'] = $row1['mobile'];
				$sqlarray[$i]['useremail'] = $row1['email'];
				$sqlarray[$i]['userprofile_image'] = UPLOAD_DIR.$row['profile_image'];
				$user = runnerdetailsbyid($row['did']);
				if($user['username']=='')
				{
					$sqlarray[$i]['runnerfullname'] = '';
				}
				else
				{
				$sqlarray[$i]['runnerfullname'] = $user['username'];
				}
				if($user['email']=='')
				{
					$sqlarray[$i]['runneremail'] = '';
				}
				else
				{
				$sqlarray[$i]['runneremail'] = $user['email'];
				}
				if($user['mobile']=='')
				{
					$sqlarray[$i]['runnermobile'] = '';
				}
				else
				{
				$sqlarray[$i]['runnermobile']=$user['mobile'];
				}
				if($user['profile_image']=='')
				{
					$sqlarray[$i]['runnerprofile_image'] = '';
				}
				else
				{
				$sqlarray[$i]['runnerprofile_image'] =  RUNNER_IMG.$user['profile_image'];
				}
				$sql1 = "SELECT * FROM `moto_delivery_price` WHERE `id` = '" . $row['delivery_plan'] . "'";
		        $sqlquery1 = mysql_query($sql1);
				$row1 = mysql_fetch_array($sqlquery1);
				$sqlarray[$i]['planid'] = $row1['id'];
				$sqlarray[$i]['planname'] = $row1['name'];
				$sqlarray[$i]['planflatrate'] = $row1['flatrate'];
				$sqlarray[$i]['plankmrate'] = $row1['kmrate'];
				$sqlarray[$i]['plancolor'] = $row1['color'];
				$i++;
			}
 
			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['Detail'] = $sqlarray;
			return $output;
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "Parcel is not available yet";
			return $output;
		}
	
}
function GetDistancesssss($data)
{
	$output = array();

	// Check that All Fields are not Empty

	if ($data['t_latitude'] == NULL || $data['t_longitude'] == NULL || $data['f_latitude'] == NULL || $data['f_longitude'] == NUll)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else
	{
		$Parceldistance = distances($data['f_latitude'], $data['f_longitude'], $data['t_latitude'], $data['t_longitude'], "K");
		$Parceldistance = round($Parceldistance);
		$output['success'] = 1;
		$output['msg'] = "Success";
		$output['distance'] = $Parceldistance;
		return $output;
	} 
}
function VerifyAccount($data)
{
	$output = array();
	if ($data['code'] == NULL)
	{
		$output['success'] = "0";
		$output['msg'] = "Check All Parameters";
		return $output;
	}
	else
	{
		$sql = "SELECT * FROM `moto_users` where  account_code='".$data['code']."'";
		$sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			$row=mysql_fetch_array($sqlquery);
			$sql = "UPDATE `moto_users` SET account_verify=1  where  account_code='".$data['code']."'";
		    $sqlquery = mysql_query($sql);
			$s = getProfilebyIds($row['userid']);
				$output["msg"] = 'Success';
				$output["success"] = "1";
				$output["userdetails"] = $s;
				$output['usertype'] = "Autho";
				$to = $row['email'];
				$message = '<table width="100%" align="center">
                 
                <tbody>

                <tr>
               	  <td valign="top" align="center" style="font-size:10px;line-height:125%;font-family:Arial,Helvetica,sans-serif;background-color:#ffffff;border-top:3px solid #cb0000">
                    	<table width="600" cellspacing="0" cellpadding="0" border="0" style="max-width:600px">
                        	<tbody><tr>
                            	<td width="600" valign="top" height="70" style="background:#f1f1f1;line-height:125%;text-align:center;padding-top:15px;padding-bottom:15px">
                                
                                		<img width="200" style="width:200px!important" src="https://ci4.googleusercontent.com/proxy/1ysunxLNk9cKo30Sg7GiDM-iHuoV7QAbt0kUqtmvis6o__u7jyPPI5yG3vS2wGGalkLTLcJ_OPNVtJ4BZCv7Wxxf0zEXU_fSU-8=s0-d-e1-ft#https://infograins.com/INFODE/pankaj/logo-xpress.png" class="CToWUd">
                                </td>
                              	
                            </tr><tr>
                         </tr></tbody></table>
                    </td>
                </tr>        
                
             
                <tr>
                	<td valign="top" bgcolor="#FFFFFF" align="center" style="background-color:#ffffff;font-family:Arial,Helvetica,sans-serif;color:#505050;font-size:14px">
                    	<u></u>	
                            <u></u><u></u>
                            <u></u><u></u>
                            <u></u><table cellspacing="0" cellpadding="0" border="0" style="width:600px;background:#f1f1f1;border-collapse:collapse">
                        
                            
                            <tbody><tr>
                            	<td width="100%" valign="middle" height="21" align="left" style="padding:10px;padding-top:30px;padding-bottom:0px">
                                	<table width="100%" height="1" cellspacing="0" cellpadding="0" border="0">
                                    	<tbody><tr>
                                        	<td valign="top" style="width:100%;padding-bottom:3px;color:#383838;font-size:20px;font-style:italic;font-weight:normal;font-family:Georgia,Times New Roman,Times,serif;border-bottom:1px solid #ececea;text-align:center">
	                                            
	                                              <u></u>Account Verification<u></u> 
	                                             
                                        	</td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                          
                        	<tr>
                            	<td valign="top" align="center" style="padding-bottom:20px">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody><tr>
                                            <td valign="top" style="padding-top:30px;padding-left:10px;padding-right:10px;padding-bottom:20px;text-align:left"><span><u></u><h3>Hello Admin,</h3>
											<p>Congratulation! your account has been verify Successfuly.Login your account ... .<br>
											<br></p>
											
											<h3>Your Email : <a target="_blank" href='.$row['email'].'>'.$row['email'].'</a></h3></span>
											<a data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=https://infograins.com/INFO01/motoxpress/login.php?email%3Dhemraj.infograins@gmail.com&amp;source=gmail&amp;ust=1474434992077000&amp;usg=AFQjCNEE2B9_0FylodtpEUfUMXofQs4inw" target="_blank" href="https://infograins.com/INFO01/motoxpress/login.php?email=hemraj.infograins@gmail.com" style="color:#fff;background:#cb0000;border-radius:5px;text-decoration:none;padding:8px 13px;display:inline-block;margin-top:10px">Please click here to login Your Account</a>
											<p style="margin-bottom:0px"><br>Thank You<br>MotoXpress Team</p>
											<u></u>
											</span></td>
                                        </tr>
                                    </tbody></table>
                                    
                                    <table width="100" cellspacing="0" cellpadding="0" border="0" align="center" style="border-collapse:collapse">
                                    	<tbody>
                                        	                   
                                         </tbody>
                                 	</table>
  								 
                                </td>
                            </tr>
                     
                        </tbody></table>
                    </td> 
              </tr>   
              <tr>
              	<td valign="top" align="center" style="background-color:#1f1f1f">
                	<span class="HOEnZb"><font color="#888888">
                         </font></span><span class="HOEnZb"><font color="#888888">
					 </font></span><table width="600" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:600px">
                    	<tbody><tr>
                        	<td valign="top" style="text-align:left;padding:10px;color:#b2b2b2;font-family:Arial,Helvetica,sans-serif;font-size:10px;line-height:150%">
                                                 <u></u>  
                                                 	

&copy; Copyright 2016 Infograins Software Solutions. All Rights Reserved.
<u></u><br><span class="HOEnZb"><font color="#888888">
                                            	
                                                
                                               
                                              
                             </font></span></td></tr></tbody></table><span class="HOEnZb"><font color="#888888">
                  </font></span></td></tr></tbody></table>';
				$subject = "Account Verification";
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .="From: info@infograins.com  \r\n ";
				$mail_sent= mail($to, $subject, $message, $headers); 
				return $output; 
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "Sorry Verification code does not match";
			return $output;
		}
	}
}


//accept request
//https://infograins.com/INFO01/motoxpress/api/api.php?action=AcceptParcel&parcelid=25&driverid=10
function AcceptParcel($data) {  
    $output = array();
if($data['parcelid']==NULL || $data['driverid']==NULL) 
	{
		$output['RESULT'] = "0";
        $output['msg'] = " check parameter";
        return $output;
	}
else if($data['parcelid']!='' ||  $data['driverid']!='') 
	{
$sqlf= "SELECT * FROM `moto_parcle_orders` where id='".$data['parcelid']."' and delivery_status='accepting' ";
	  $sqlqueryf=mysql_query($sqlf);
	 $num=mysql_num_rows($sqlqueryf);
		if($num > 0)
		{
			$sqlfd= "SELECT * FROM `moto_parcle_orders` where id='".$data['parcelid']."' and delivery_status='accepting' ";
	  $sqlqueryfd=mysql_query($sqlfd);
	 $numd=mysql_num_rows($sqlqueryfd);
		if($numd > 0)
		{
	    	$output['msg'] = "Job is already accept";
            $output["RESULT"] = "0"; 
         return $output;
		}
		
    
}
else
{
	 $sqlll="UPDATE `moto_parcle_orders` SET did='".$data['driverid']."', `delivery_status`='accepting'  WHERE id='".$data['parcelid']."'";
	 $sqlqueryyy=mysql_query($sqlll);	
if($sqlqueryyy)	 
{
	

		  $dsql1 = "SELECT * FROM `moto_runner` where rid='".$data['driverid']."' ";
		   $dsqlquery1=mysql_query($dsql1);
		    $rowd=mysql_fetch_array($dsqlquery1);
			
		  $divername= $rowd['username'];
	 $sqls = "SELECT * FROM `moto_parcle_orders` where `id`='".$data['parcelid']."' ";
	   $sqlqueryy=mysql_query($sqls);
		  $rows=mysql_fetch_array($sqlqueryy);
		    $parcel_notification = "INSERT INTO `moto_parcel_notification` (`uid`,`pid`,`notification`,`status`) VALUES('".$rows['uid']."','".$data['parcelid']."','accepting','0')";
       
        $sql_notification = mysql_query($parcel_notification);
		  $sqlsu = "SELECT * FROM `moto_users` where `userid`='".$rows['uid']."' and noti_status='1' ";
	   $sqlqueryyu=mysql_query($sqlsu);
		  $rowsu=mysql_fetch_array($sqlqueryyu);
		  $deviceid=$rowsu['device_id'];
			 $device_type=$rowsu['device_type'];
			$d=$rows['delivery_status'];
			$u=$rowd['username'];
			if($deviceid != NULL)
			{
				$message1 = 'Parcel $d'; 
				$message2 = "Your parcel is accepted by $u"; 
				if($device_type == 'android')
				{	
					$registatoin_ids = array($deviceid);
					$message123 = array("msg" => $message1,"notification" => $message2,"parcelid" => $data['parcelid'],"driverid" =>$rows['did'],"drivername" =>$u,"delivery_status" =>$d); 
				    $result1=sendMessage($message123,$registatoin_ids); 
				}	
				else if($device_type == 'ios')
				{	
					$registatoin_ids = array($deviceid);
					$message123 = array("msg" => $message1,"notification" => $message2,"parcelid" => $data['parcelid'],"driverid" =>$data['did'],"drivername" =>$u,"delivery_status" =>$d,"notitype" =>'acceptdriver') ;
					 $result1=sendnotificationiosUser($registatoin_ids,$message123);  
				}
			
			}
		  	$to=$rows['noti_email'];
	        $message = '<html><head><title>Parcel Status </title></head><body><table width="100%" align="center"><tbody><tr>
               	  <td valign="top" align="center" style="font-size:10px;line-height:125%;font-family:Arial,Helvetica,sans-serif;background-color:#ffffff;border-top:3px solid #cb0000">
                    	<table width="600" cellspacing="0" cellpadding="0" border="0" style="max-width:600px">
                        <tbody><tr><td width="600" valign="top" height="70" style="background:#f1f1f1;line-height:125%;text-align:center;padding-top:15px;padding-bottom:15px">
                              <img width="200" style="width:200px!important" src="https://ci4.googleusercontent.com/proxy/1ysunxLNk9cKo30Sg7GiDM-iHuoV7QAbt0kUqtmvis6o__u7jyPPI5yG3vS2wGGalkLTLcJ_OPNVtJ4BZCv7Wxxf0zEXU_fSU-8=s0-d-e1-ft#https://infograins.com/INFODE/pankaj/logo-xpress.png" class="CToWUd">
                                </td>
                              	
                            </tr><tr>
                         </tr></tbody></table>
                    </td>
                </tr>        
              
                <tr>
                	<td valign="top" bgcolor="#FFFFFF" align="center" style="background-color:#ffffff;font-family:Arial,Helvetica,sans-serif;color:#505050;font-size:14px">
                    	<u></u>	
                            <u></u><u></u>
                            <u></u><u></u>
                            <u></u><table cellspacing="0" cellpadding="0" border="0" style="width:600px;background:#f1f1f1;border-collapse:collapse">
                            <tbody><tr>
                            	<td width="100%" valign="middle" height="21" align="left" style="padding:10px;padding-top:30px;padding-bottom:0px">
                                	<table width="100%" height="1" cellspacing="0" cellpadding="0" border="0">
                                    	<tbody><tr>
                                        	<td valign="top" style="width:100%;padding-bottom:3px;color:#383838;font-size:20px;font-style:italic;font-weight:normal;font-family:Georgia,Times New Roman,Times,serif;border-bottom:1px solid #ececea;text-align:center">
	                                            
	                                              <u></u>Accept Parcel Status<u></u> 
	                                             
                                        	</td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                       	     <tr>
                            	<td valign="top" align="center" style="padding-bottom:20px">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody><tr>
                                            <td valign="top" style="padding-top:30px;padding-left:10px;padding-right:10px;padding-bottom:20px;text-align:left"><span><u></u><h3>Hello '.$rowsu['fullname'].',</h3>
											<p>Congratulation! your parcel has been accepted  by '.$divername.' . There are Details given below..<br>
											<br></p>
											
											<h3>Your Email : <a target="_blank" href='.$to.'>'.$to.'</a></h3></span><h3>Pick up address: </h3>'.$rows['picupaddress'].'<span>
										 </h3></span><h3>Pick up address: </h3>'.$rows['picupaddress'].'<span>
										 </h3></span><h3>Dropoff address: </h3>'.$rows['dropoffaddress'].'<span>
										 </h3></span><h3>Total distance: </h3>'.$rows['total_distance'].'<span>
										 </h3></span><h3>Deliver by: </h3>'.$rows['deliver_by'].'<span>
										 </h3></span><h3>Pic at time: </h3>'.$rows['pic_at_time'].'<span>
										
											<p style="margin-bottom:0px"><br>Thank You<br>MotoXpress Team</p>
											<u></u>
											</span></td>
                                        </tr>
                                    </tbody></table>
                                    
                                    <table width="100" cellspacing="0" cellpadding="0" border="0" align="center" style="border-collapse:collapse">
                                    	<tbody>
                                        	                   
                                         </tbody>
                                 	</table>
  								 
                                </td>
                            </tr>
                          
                        </tbody></table>
                    </td> 
              </tr>   
              <tr>
              	<td valign="top" align="center" style="background-color:#1f1f1f">
                	<span class="HOEnZb"><font color="#888888">
                         </font></span><span class="HOEnZb"><font color="#888888">
					 </font></span><table width="600" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:600px">
                    	<tbody><tr>
                        	<td valign="top" style="text-align:left;padding:10px;color:#b2b2b2;font-family:Arial,Helvetica,sans-serif;font-size:10px;line-height:150%">
                                                 <u></u>&copy; Copyright 2016 Infograins Software Solutions. All Rights Reserved.
                                                       <u></u><br><span class="HOEnZb"><font color="#888888">
                                  </font></span></td></tr></tbody></table><span class="HOEnZb"><font color="#888888">
                                 </font></span></td></tr></tbody></table></body></html>';
					$subject = "Parcel Accepted";
					$headers  = 'MIME-Version: 1.0' . "\r\n";
					$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
					$headers .="From: info@infograins.com  \r\n ";
					$mail_sent= mail($to, $subject, $message, $headers); 
			         $output['RESULT'] = "1";
	 	            $output['msg'] = "Job is accept";
                   $output["RESULT"] = "1";
                    return $output;
}
}
	
	}
	 else
	 {
		 $output['msg'] = "unsuccess";
         $output["RESULT"] = "0"; 
         return $output;
	 }

		
}




//accept request
//https://infograins.com/INFO01/motoxpress/api/api.php?action=ParcelDeliveryStatus&parcelid=25&delivery_status=picking
function ParcelDeliveryStatus($data) {  
    $output = array();
if($data['parcelid']==NULL || $data['delivery_status']==NULL) 
	{
		$output['RESULT'] = "0";
        $output['msg'] = " check parameter";
        return $output;
	}
else if($data['parcelid']!='' || $data['delivery_status']!='') 
	{
	 $sqlll="UPDATE `moto_parcle_orders` SET `delivery_status`='".$data['delivery_status']."'  WHERE id='".$data['parcelid']."'";
	 $sqlqueryyy=mysql_query($sqlll);	
if($sqlqueryyy)	 
{		
	 $sqls = "SELECT * FROM `moto_parcle_orders` where `id`='".$data['parcelid']."' ";
	   $sqlqueryy=mysql_query($sqls);
		  $rows=mysql_fetch_array($sqlqueryy);
		    // $parcel_notification = "INSERT INTO `moto_parcel_notification` (`uid`,`pid`,`notification`,`status`) VALUES('".$rows['uid']."','".$data['parcelid']."','".$data['delivery_status']."','0')";
       
        // $sql_notification = mysql_query($parcel_notification);
if($data['delivery_status']=='picking')
{
$d='picked up';	
}
else if ($data['delivery_status']=='running'){
$d='delivered very soon';
}


	    $parcel_notification = "update  `moto_parcel_notification` set `notification`='".$data['delivery_status']."' where pid='".$data['parcelid']."'";
			$sql_notification = mysql_query($parcel_notification);
		   $dsql1 = "SELECT * FROM `moto_runner` where rid='".$rows['did']."' ";
		   $dsqlquery1=mysql_query($dsql1);
		    $rowd=mysql_fetch_array($dsqlquery1);
		  $sqlsu = "SELECT * FROM `moto_users` where `userid`='".$rows['uid']."' and noti_status='1' ";
	   $sqlqueryyu=mysql_query($sqlsu);
		  $rowsu=mysql_fetch_array($sqlqueryyu);
		  	$to=$rows['noti_email'];
			//$d=$rows['delivery_status'];
			$u=$rowd['username'];
			 $deviceid=$rowsu['device_id'];;
			 $device_type=$rowsu['device_type'];
			if($deviceid != NULL)
			{
				$message1 = "Parcel $d"; 
				$message2 = "Your Parcel is $d by $u"; 
				if($device_type == 'android')
				{	
					$registatoin_ids = array($deviceid);
					$message123 = array("msg" => $message1,"notification" => $message2,"parcelid" => $data['parcelid'],"driverid" =>$rows['did'],"drivername" =>$u,"delivery status" =>$d); 
				    $result1=sendMessage($message123,$registatoin_ids); 
				}	
				else if($device_type == 'ios')
				{	
					$registatoin_ids = array($deviceid);
				$message123 = array("msg" => $message1,"notification" => $message2,"parcelid" => $data['parcelid'],"driverid" =>$rows['did'],"drivername" =>$u,"delivery_status" =>$d,"notitype" =>'deliverystatus') ;
					 $result1=sendnotificationiosUser($registatoin_ids,$message123);  
				}
			
			}	

                    $message = '<html><head><title>Parcel Status </title></head><body><table width="100%" align="center">
                 
                <tbody>
               <tr>
               	  <td valign="top" align="center" style="font-size:10px;line-height:125%;font-family:Arial,Helvetica,sans-serif;background-color:#ffffff;border-top:3px solid #cb0000">
                    	<table width="600" cellspacing="0" cellpadding="0" border="0" style="max-width:600px">
                        	<tbody><tr>
                            	<td width="600" valign="top" height="70" style="background:#f1f1f1;line-height:125%;text-align:center;padding-top:15px;padding-bottom:15px">
                                
                                		<img width="200" style="width:200px!important" src="https://ci4.googleusercontent.com/proxy/1ysunxLNk9cKo30Sg7GiDM-iHuoV7QAbt0kUqtmvis6o__u7jyPPI5yG3vS2wGGalkLTLcJ_OPNVtJ4BZCv7Wxxf0zEXU_fSU-8=s0-d-e1-ft#https://infograins.com/INFODE/pankaj/logo-xpress.png" class="CToWUd">
                                </td>
                              	
                            </tr><tr>
                         </tr></tbody></table>
                    </td>
                </tr>        
                
                <tr>
                	<td valign="top" bgcolor="#FFFFFF" align="center" style="background-color:#ffffff;font-family:Arial,Helvetica,sans-serif;color:#505050;font-size:14px">
                    	<u></u>	
                            <u></u><u></u>
                            <u></u><u></u>
                            <u></u><table cellspacing="0" cellpadding="0" border="0" style="width:600px;background:#f1f1f1;border-collapse:collapse">
                        
                            
                            <tbody><tr>
                            	<td width="100%" valign="middle" height="21" align="left" style="padding:10px;padding-top:30px;padding-bottom:0px">
                                	<table width="100%" height="1" cellspacing="0" cellpadding="0" border="0">
                                    	<tbody><tr>
                                        	<td valign="top" style="width:100%;padding-bottom:3px;color:#383838;font-size:20px;font-style:italic;font-weight:normal;font-family:Georgia,Times New Roman,Times,serif;border-bottom:1px solid #ececea;text-align:center">
	                                            
	                                              <u></u>Parcel Delivery  Status<u></u> 
	                                             
                                        	</td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                           
                        	<tr>
                            	<td valign="top" align="center" style="padding-bottom:20px">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody><tr>
                                            <td valign="top" style="padding-top:30px;padding-left:10px;padding-right:10px;padding-bottom:20px;text-align:left"><span><u></u><h3>Hello '.$rowsu['fullname'].',</h3>
                                            <h3>Your Parcel '.$rows['delivery_status'].' by '.$rowd['username'].',</h3>
											<p>your parcel status has been generate details ...<br>
											<br></p>
											
											<h3>Your Email : <a target="_blank" href='.$rows['noti_email'].'>'.$rows['noti_email'].'</a></h3></span><h4>Delivery status : '.$rows['delivery_status'].'</h4>
                                          
                                            <h4>Pickup Address : '.$rows['picupaddress'].'</h4>
                                            <h4>Pickup time :'.$rows['pic_at_time'].'</h4> 
                                            <h4>Drop off address:'.$rows['dropoffaddress'].'</h4> 
                                            <h4>Delivery plan:'.$rows['delivery_plan'].'</h4>
                                             <h4>Delivery time:'.$rows['delivery_time'].'</h4>
                                             <h4>Parcle type:'.$rows['parcle_type'].'</h4>
											<span>
										
											<p style="margin-bottom:0px"><br>Thank You<br>MotoXpress Team</p>
											<u></u>
											</span></td>
                                        </tr>
                                    </tbody></table>
                                    
                                    <table width="100" cellspacing="0" cellpadding="0" border="0" align="center" style="border-collapse:collapse">
                                    	<tbody>
                                        	                   
                                         </tbody>
                                 	</table>
  								 
                                </td>
                            </tr>
                         
                        </tbody></table>
                    </td> 
              </tr>   
              <tr>
              	<td valign="top" align="center" style="background-color:#1f1f1f">
                	<span class="HOEnZb"><font color="#888888">
                         </font></span><span class="HOEnZb"><font color="#888888">
					 </font></span><table width="600" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:600px">
                    	<tbody><tr>
                        	<td valign="top" style="text-align:left;padding:10px;color:#b2b2b2;font-family:Arial,Helvetica,sans-serif;font-size:10px;line-height:150%">
                                                 <u></u>  
                                                 	

&copy; Copyright 2016 Infograins Software Solutions. All Rights Reserved.
<u></u><br><span class="HOEnZb"><font color="#888888">
                                            	
                                                
                                               
                                              
                             </font></span></td></tr></tbody></table><span class="HOEnZb"><font color="#888888">
                  </font></span></td></tr></tbody></table></body></html>';
					$subject = "Parcel $d";
					$headers  = 'MIME-Version: 1.0' . "\r\n";
					$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
					$headers .="From: info@infograins.com  \r\n ";
					$mail_sent= mail($to, $subject, $message, $headers); 
			         $output['RESULT'] = "1";
	 	            $output['msg'] = "success";
                   $output["RESULT"] = "1";
                    return $output;
}
}
	
	
	 else
	 {
		 $output['msg'] = "unsuccess";
         $output["RESULT"] = "0"; 
         return $output;
	 }

		
}

//accept request
//https://infograins.com/INFO01/motoxpress/api/api.php?action=ParcelDeliveryComplete&parcelid=25&driverid=1&receiptname=dg
function ParcelDeliveryComplete($data) {  
    $output = array();
if($data['parcelid']==NULL || $data['driverid']==NULL || $data['receiptname']==NULL) 
	{
		$output['RESULT'] = "0";
        $output['msg'] = " check parameter";
        return $output;
	}
else if($data['parcelid']!='' || $data['driverid']!='' || $data['receiptname']!='') 
	{
		$image = $_FILES['signature']['name'];  

			$image= time().$image;  
			$uploadfile=UPLOAD_DIR_SIGN.$image;
			move_uploaded_file($_FILES['signature']['tmp_name'],$uploadfile);
			
			$images = $_FILES['image']['name'];  

			$images= time().$images;  
			$uploadfile=UPLOAD_DIR_SIGN.$images;
			move_uploaded_file($_FILES['image']['tmp_name'],$uploadfile);
			 date_default_timezone_set('Asia/Calcutta'); 
		$date=date('Y-m-d G:i:s');
		$sqllll="insert into `signature_tbl` SET `orderid`='".$data['parcelid']."',`driverid`='".$data['driverid']."',`rname`='".$data['receiptname']."',`signature`='$image' ,`image`='$images',`date`='$date' ";
	 $sqlqueryyyy=mysql_query($sqllll); 
	// else if ($data['delivery_status']=='completing'){
	
	// $d='completed';
// }
	
if($sqlqueryyyy)	 
{		
 $sqlll="UPDATE  `moto_parcle_orders` SET  `delivery_status` =  'completing' WHERE  `id` =  '".$data['parcelid']."'";
	 $sqlqueryyy=mysql_query($sqlll);	
	 $sqls = "SELECT * FROM `moto_parcle_orders` where `id`='".$data['parcelid']."' ";
	   $sqlqueryy=mysql_query($sqls);
		  $rows=mysql_fetch_array($sqlqueryy);
		     // $dsql1p = "SELECT * FROM `moto_runner` where rid='".$rows['did']."' ";
		   // $dsqlquery1p=mysql_query($dsql1p);
		   // $num = mysql_num_rows($dsqlquery1p);
			  // if($num>0)
			  // {
				  
			  // }
			  // else{
		    $parcel_notification = "update  `moto_parcel_notification` set `notification`='completing' where pid='".$data['parcelid']."'";
       
        $sql_notification = mysql_query($parcel_notification);
			 // }
		   $dsql1 = "SELECT * FROM `moto_runner` where rid='".$rows['did']."' ";
		   $dsqlquery1=mysql_query($dsql1);
		    $rowd=mysql_fetch_array($dsqlquery1);
		  $sqlsu = "SELECT * FROM `moto_users` where `userid`='".$rows['uid']."' and noti_status='1'";
	   $sqlqueryyu=mysql_query($sqlsu);
		  $rowsu=mysql_fetch_array($sqlqueryyu);
		  	$to=$rows['noti_email'];
			$d=$rows['delivery_status'];
			$u=$rowd['username'];
			 $deviceid=$rowsu['device_id'];;
			 $device_type=$rowsu['device_type'];
			if($deviceid != NULL)
			{
				$message1 = "Parcel $d"; 
				$message2 = "Your Parcel is completed by $u"; 
				if($device_type == 'android')
				{	
					$registatoin_ids = array($deviceid);
					$message123 = array("msg" => $message1,"notification" => $message2,"parcelid" => $data['parcelid'],"driverid" =>$rows['did'],"drivername" =>$u,"delivery status" =>$d); 
				    $result1=sendMessage($message123,$registatoin_ids); 
				}	
				else if($device_type == 'ios')
				{	
					$registatoin_ids = array($deviceid);
					$message123 = array("msg" => $message1,"notification" => $message2,"parcelid" => $data['parcelid'],"driverid" =>$rows['did'],"drivername" =>$u,"delivery status" =>$d,'notitype'=>'deliverycomplete') ;
					 $result1=sendnotificationiosUser($registatoin_ids,$message123);  
				}
			
			}	

                    $message = '<html><head><title>Parcel Status </title></head><body><table width="100%" align="center">
                 
                <tbody>
               <tr>
               	  <td valign="top" align="center" style="font-size:10px;line-height:125%;font-family:Arial,Helvetica,sans-serif;background-color:#ffffff;border-top:3px solid #cb0000">
                    	<table width="600" cellspacing="0" cellpadding="0" border="0" style="max-width:600px">
                        	<tbody><tr>
                            	<td width="600" valign="top" height="70" style="background:#f1f1f1;line-height:125%;text-align:center;padding-top:15px;padding-bottom:15px">
                                
                                		<img width="200" style="width:200px!important" src="https://ci4.googleusercontent.com/proxy/1ysunxLNk9cKo30Sg7GiDM-iHuoV7QAbt0kUqtmvis6o__u7jyPPI5yG3vS2wGGalkLTLcJ_OPNVtJ4BZCv7Wxxf0zEXU_fSU-8=s0-d-e1-ft#https://infograins.com/INFODE/pankaj/logo-xpress.png" class="CToWUd">
                                </td>
                              	
                            </tr><tr>
                         </tr></tbody></table>
                    </td>
                </tr>        
                
                <tr>
                	<td valign="top" bgcolor="#FFFFFF" align="center" style="background-color:#ffffff;font-family:Arial,Helvetica,sans-serif;color:#505050;font-size:14px">
                    	<u></u>	
                            <u></u><u></u>
                            <u></u><u></u>
                            <u></u><table cellspacing="0" cellpadding="0" border="0" style="width:600px;background:#f1f1f1;border-collapse:collapse">
                        
                            
                            <tbody><tr>
                            	<td width="100%" valign="middle" height="21" align="left" style="padding:10px;padding-top:30px;padding-bottom:0px">
                                	<table width="100%" height="1" cellspacing="0" cellpadding="0" border="0">
                                    	<tbody><tr>
                                        	<td valign="top" style="width:100%;padding-bottom:3px;color:#383838;font-size:20px;font-style:italic;font-weight:normal;font-family:Georgia,Times New Roman,Times,serif;border-bottom:1px solid #ececea;text-align:center">
	                                            
	                                              <u></u>Parcel Delivery  Status<u></u> 
	                                             
                                        	</td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                           
                        	<tr>
                            	<td valign="top" align="center" style="padding-bottom:20px">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody><tr>
                                            <td valign="top" style="padding-top:30px;padding-left:10px;padding-right:10px;padding-bottom:20px;text-align:left"><span><u></u><h3>Hello '.$rowsu['fullname'].',</h3>
                                            <h3>Your Parcel '.$rows['delivery_status'].' by '.$rowd['username'].',</h3>
											<p>your parcel status has been generate details ...<br>
											<br></p>
											
											<h3>Your Email : <a target="_blank" href='.$rows['noti_email'].'>'.$rows['noti_email'].'</a></h3></span><h4>Delivery status : '.$rows['delivery_status'].'</h4>
                                          
                                            <h4>Pickup Address : '.$rows['picupaddress'].'</h4>
                                            <h4>Drop off address:'.$rows['dropoffaddress'].'</h4> 
                                            <h4>Delivery plan:'.$rows['delivery_plan'].'</h4>
                                             <h4>Delivery time:'.$rows['delivery_time'].'</h4>
                                             <h4>Parcle type:'.$rows['parcle_type'].'</h4>
											<span>
										
											<p style="margin-bottom:0px"><br>Thank You<br>MotoXpress Team</p>
											<u></u>
											</span></td>
                                        </tr>
                                    </tbody></table>
                                    
                                    <table width="100" cellspacing="0" cellpadding="0" border="0" align="center" style="border-collapse:collapse">
                                    	<tbody>
                                        	                   
                                         </tbody>
                                 	</table>
  								 
                                </td>
                            </tr>
                         
                        </tbody></table>
                    </td> 
              </tr>   
              <tr>
              	<td valign="top" align="center" style="background-color:#1f1f1f">
                	<span class="HOEnZb"><font color="#888888">
                         </font></span><span class="HOEnZb"><font color="#888888">
					 </font></span><table width="600" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:600px">
                    	<tbody><tr>
                        	<td valign="top" style="text-align:left;padding:10px;color:#b2b2b2;font-family:Arial,Helvetica,sans-serif;font-size:10px;line-height:150%">
                                                 <u></u>  
                                                 	

&copy; Copyright 2016 Infograins Software Solutions. All Rights Reserved.
<u></u><br><span class="HOEnZb"><font color="#888888">
                                            	
                                                
                                               
                                              
                             </font></span></td></tr></tbody></table><span class="HOEnZb"><font color="#888888">
                  </font></span></td></tr></tbody></table></body></html>';
					$subject = "Parcel $d";
					$headers  = 'MIME-Version: 1.0' . "\r\n";
					$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
					$headers .="From: info@infograins.com  \r\n ";
					$mail_sent= mail($to, $subject, $message, $headers); 
			         $output['RESULT'] = "1";
	 	            $output['msg'] = "success";
                    return $output;
}

	
	
	 else
	 {
		 $output['msg'] = "unsuccess";
         $output["RESULT"] = "0"; 
         return $output;
	 }

		
}
}


// ge order hostory
// https://infograins.com/INFO01/tayar/API/api.php?action=ParcelList&delivery_status=pending&userid

function ParcelList($data)
{
	$output = array();
if ($data['delivery_status'] == NULL  )
	{ 
		$output['success'] = "0";
		$output['msg'] = "Check All Parameters";
		return $output;
	}
	else
	if ($data['delivery_status'] != '')
	{
		$result = getparcellisting($data['delivery_status'],$data['userid'],$data['runnerid'],$data['page']);
		
		if ($result == NULL)
		{
			if($data['runnerid']!='')
		{
			$output['success'] = "0";
			$output['msg'] = "Job is not available yet";
			return $output;
		}
		else
		{
		    $output['success'] = "0";
			$output['msg'] = "No more delivery found";
			return $output;
		}
			
		}
		else
		{
			$output['success'] = "1";
			$output['msg'] = "successfully";
			$output['parcellist'] = $result;
			return $output;
		}
	}
}

function getparcellisting($did,$uid,$rid,$page)
{
	$num_rec_per_page=3;
    $start_from = ($page) * $num_rec_per_page;
	$msgtype= str_replace("\r\n","",$msgtyp);
	if($uid!='')
	{
		if($did=='all')
		{ 
			 $sql = "SELECT t . * , u . * FROM  `moto_parcle_orders` AS t INNER JOIN moto_users AS u ON t.`uid` = u.userid WHERE  `uid` =  '$uid' LIMIT $start_from, $num_rec_per_page ";
		}
		else if($did!='all')
		{
	 $sql = "SELECT t . * , u . * FROM  `moto_parcle_orders` AS t INNER JOIN moto_users AS u ON t.`uid` = u.userid WHERE  `uid` =  '$uid' and t.delivery_status='$did' LIMIT $start_from, $num_rec_per_page";
		}
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num > 0)
	{
		$i = 0;
		while ($row = mysql_fetch_array($sqlquery))
		{
			    $sqlarray[$i]['parcelid'] = $row['id'];
				$sqlarray[$i]['userfullname'] = $row['fullname'];
				$sqlarray[$i]['useremail'] = $row['email'];
				$sqlarray[$i]['usermobile'] = $row['mobile'];
				$sqlarray[$i]['userprofile_image'] = UPLOAD_DIR.$row['profile_image'];
				$user = runnerdetailsbyid($row['did']);
				if($user['username']=='')
				{
					$sqlarray[$i]['runnerfullname'] = '';
				}
				else
				{
				$sqlarray[$i]['runnerfullname'] = $user['username'];
				}
				if($user['email']=='')
				{
					$sqlarray[$i]['runneremail'] = '';
				}
				else
				{
				$sqlarray[$i]['runneremail'] = $user['email'];
				}
				if($user['mobile']=='')
				{
					$sqlarray[$i]['runnermobile'] = '';
				}
				else
				{
				$sqlarray[$i]['runnermobile']=$user['mobile'];
				}
				if($user['profile_image']=='')
				{
					$sqlarray[$i]['runnerprofile_image'] = '';
				}
				else
				{
				$sqlarray[$i]['runnerprofile_image'] =  RUNNER_IMG.$user['profile_image'];
				}
                $sqlarray[$i]['picupaddress']=$row['picupaddress'];
				$sqlarray[$i]['dropoffaddress']=$row['dropoffaddress'];
				$sqlarray[$i]['picupcontactname']=$row['picupcontactname'];
				$sqlarray[$i]['dropoffcontactname']=$row['dropoffcontactname'];
				$sqlarray[$i]['pickupunitnumber']=$row['pickupunitnumber'];
				$sqlarray[$i]['dropoffunitnumber']=$row['dropoffunitnumber'];
				$sqlarray[$i]['pickupcnatctnumber']=$row['pickupcnatctnumber'];
				$sqlarray[$i]['dropoffcontactnumber']=$row['dropoffcontactnumber'];
				$sqlarray[$i]['picupcompany']=$row['picupcompany'];
				$sqlarray[$i]['dropoffcompany']=$row['dropoffcompany'];
				$sqlarray[$i]['photo']=$row['photo'];
				$sqlarray[$i]['short_ins']=$row['short_ins'];
				$sqlarray[$i]['delivery_ins']=$row['delivery_ins'];
				$sqlarray[$i]['noti_email']=$row['noti_email'];
				$sqlarray[$i]['payment_method']=$row['payment_method'];
				$sqlarray[$i]['photo']=$row['photo'];
				$sqlarray[$i]['short_ins']=$row['short_ins'];
				$sqlarray[$i]['delivery_ins']=$row['delivery_ins'];
				$sqlarray[$i]['noti_email']=$row['noti_email'];
				$sqlarray[$i]['cdate']=$row['cdate'];
				$sqlarray[$i]['total_cost']=$row['total_cost'];
				$sqlarray[$i]['delivery_plan']=$row['delivery_plan'];
				$sqlarray[$i]['delivery_time']=$row['delivery_time'];
				$sqlarray[$i]['total_distance']=$row['total_distance'];
				$sqlarray[$i]['deliver_by']=$row['deliver_by'];
				$sqlarray[$i]['total_cost']=$row['total_cost'];
				$sqlarray[$i]['pic_at_time']=$row['pic_at_time'];
				$sqlarray[$i]['delivery_time']=$row['delivery_time'];
				$sqlarray[$i]['total_distance']=$row['total_distance'];
				$sqlarray[$i]['parcle_type']=$row['parcle_type'];
				$sqlarray[$i]['no_of_item']=$row['no_of_item'];
				$sqlarray[$i]['width']=$row['width'];
				$sqlarray[$i]['height']=$row['height'];
				$sqlarray[$i]['weight']=$row['weight'];
				$sqlarray[$i]['length']=$row['length'];
				$sqlarray[$i]['delivery_status']=$row['delivery_status'];
				$sqlarray[$i]['payment_status']=$row['payment_status'];
				$sqlarray[$i]['status']=$row['status'];
				$sqlarray[$i]['plat']=$row['plat'];
				$sqlarray[$i]['plong']=$row['plong'];
				$sqlarray[$i]['dlat']=$row['dlat'];
				$sqlarray[$i]['dlong']=$row['dlong'];
				$sqlarray[$i]['did']=$row['did'];
				
				 $sqlff = "SELECT * FROM  `user_driver_feedback`  WHERE  `parcelid` =  '".$row['id']."'";
				 $sqlqueryff = mysql_query($sqlff);
		$rows = mysql_fetch_array($sqlqueryff);
		$numm = mysql_num_rows($sqlqueryff);
	if ($numm > 0)
	{
        $sqlarray[$i]['feedback_status']='1';
	}else   
	{
		$sqlarray[$i]['feedback_status']='0';
	}
		 
				
				 $sqlf = "SELECT * FROM  `signature_tbl`  WHERE  `orderid` =  '".$row['id']."'";
				 $sqlqueryf = mysql_query($sqlf);
		$rows = mysql_fetch_array($sqlqueryf);
		$num = mysql_num_rows($sqlqueryf);
	if ($num > 0)
	{
        $sqlarray[$i]['delivery_complete_time']=$rows['date'];
	}else   
	{
		$sqlarray[$i]['delivery_complete_time']="";
	}
		 
	
	
		
			$i++;
		
		}
	}
	}
	
	else
	{
		if($did=='all')
		{
		 $sql = "SELECT t . * , u . * FROM  `moto_parcle_orders` AS t INNER JOIN moto_runner AS u ON t.`did` = u.rid WHERE  `did` =  '$rid' and delivery_status!= 'completing' LIMIT $start_from, $num_rec_per_page ";
		}
		else if($did!='all')
		{
		$sql = "SELECT t . * , u . * FROM  `moto_parcle_orders` AS t INNER JOIN moto_runner AS u ON t.`did` = u.rid WHERE  `did` =  '$rid' and t.delivery_status='$did' LIMIT $start_from, $num_rec_per_page ";	
		}
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num > 0)
	{
		$i = 0;
		while ($row = mysql_fetch_array($sqlquery))
		{
			    $sqlarray[$i]['parcelid'] = $row['id'];
			    $user = userdetailsbyid($row['uid']);
				if($user['fullname']=='')
				{
				$sqlarray[$i]['userfullname'] = '';	
				}
				else
				{
				$sqlarray[$i]['userfullname'] = $user['fullname'];
				}
				if($user['useremail']=='')
				{
				$sqlarray[$i]['useremail'] = '';	
				}
				else
				{
				$sqlarray[$i]['useremail'] = $user['email'];
				}
				if($user['mobile']=='')
				{
				$sqlarray[$i]['usermobile'] = '';	
				}
				else
				{
				$sqlarray[$i]['usermobile'] = $user['mobile'];
				}
				if($user['profile_image']=='')
				{
				$sqlarray[$i]['userprofile_image'] = '';	
				}
				else
				{
				$sqlarray[$i]['userprofile_image'] = UPLOAD_DIR.$user['profile_image'];
				}
				$sqlarray[$i]['runnerfullname'] = $row['username'];
				$sqlarray[$i]['runneremail'] = $row['email'];
				$sqlarray[$i]['runnermobile']=$row['mobile'];
				$sqlarray[$i]['runnerprofile_image'] =  RUNNER_IMG.$row['profile_image'];
				 $sqlarray[$i]['uid']=$row['uid'];
                $sqlarray[$i]['picupaddress']=$row['picupaddress'];
				$sqlarray[$i]['dropoffaddress']=$row['dropoffaddress'];
				$sqlarray[$i]['picupcontactname']=$row['picupcontactname'];
				$sqlarray[$i]['dropoffcontactname']=$row['dropoffcontactname'];
				$sqlarray[$i]['pickupunitnumber']=$row['pickupunitnumber'];
				$sqlarray[$i]['dropoffunitnumber']=$row['dropoffunitnumber'];
				$sqlarray[$i]['pickupcnatctnumber']=$row['pickupcnatctnumber'];
				$sqlarray[$i]['dropoffcontactnumber']=$row['dropoffcontactnumber'];
				$sqlarray[$i]['picupcompany']=$row['picupcompany'];
				$sqlarray[$i]['dropoffcompany']=$row['dropoffcompany'];
				$sqlarray[$i]['photo']=$row['photo'];
				$sqlarray[$i]['short_ins']=$row['short_ins'];
				$sqlarray[$i]['delivery_ins']=$row['delivery_ins'];
				$sqlarray[$i]['noti_email']=$row['noti_email'];
				$sqlarray[$i]['payment_method']=$row['payment_method'];
				$sqlarray[$i]['photo']=$row['photo'];
				$sqlarray[$i]['short_ins']=$row['short_ins'];
				$sqlarray[$i]['delivery_ins']=$row['delivery_ins'];
				$sqlarray[$i]['noti_email']=$row['noti_email'];
				$sqlarray[$i]['cdate']=$row['cdate'];
				$sqlarray[$i]['total_cost']=$row['total_cost'];
				$sqlarray[$i]['delivery_plan']=$row['delivery_plan'];
				$sqlarray[$i]['delivery_time']=$row['delivery_time'];
				$sqlarray[$i]['total_distance']=$row['total_distance'];
				$sqlarray[$i]['deliver_by']=$row['deliver_by'];
				$sqlarray[$i]['total_cost']=$row['total_cost'];
				$sqlarray[$i]['pic_at_time']=$row['pic_at_time'];
				$sqlarray[$i]['delivery_time']=$row['delivery_time'];
				$sqlarray[$i]['total_distance']=$row['total_distance'];
				$sqlarray[$i]['parcle_type']=$row['parcle_type'];
				$sqlarray[$i]['no_of_item']=$row['no_of_item'];
				$sqlarray[$i]['width']=$row['width'];
				$sqlarray[$i]['height']=$row['height'];
				$sqlarray[$i]['weight']=$row['weight'];
				$sqlarray[$i]['length']=$row['length'];
				$sqlarray[$i]['delivery_status']=$row['delivery_status'];
				$sqlarray[$i]['payment_status']=$row['payment_status'];
				$sqlarray[$i]['status']=$row['status'];
				$sqlarray[$i]['plat']=$row['plat'];
				$sqlarray[$i]['plong']=$row['plong'];
				$sqlarray[$i]['dlat']=$row['dlat'];
				$sqlarray[$i]['dlong']=$row['dlong'];
				$sqlarray[$i]['did']=$row['did'];
				



			$i++;
		}
	}
	}

	return $sqlarray;
}



function runnerdetailsbyid($did)
{
	$sql = "SELECT * FROM `moto_runner` WHERE `rid` = '" . $did. "'";
		$sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			
			while ($row = mysql_fetch_array($sqlquery))
			{
				$sqlarray['id'] = $row['rid'];
				$sqlarray['username'] = $row['username'];
				$sqlarray['email'] = $row['email'];
				$sqlarray['mobile'] = $row['mobile'];
				$sqlarray['profile_image'] = RUNNER_IMG.$row['profile_image'];
				

				
			}
			$i++;
		}
	

	return $sqlarray;
}


function userdetailsbyid($id)
{
	$sql = "SELECT * FROM `moto_users` WHERE `userid` = '" . $id . "'";
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num > 0)
	{
		while ($row = mysql_fetch_array($sqlquery))
		{
			$sqlarray['userid'] = $row['userid'];
			$sqlarray['fullname'] = $row['fullname'];
			$sqlarray['email'] = $row['email'];
			$sqlarray['mobile'] = $row['mobile'];
			$sqlarray['profile_image'] = UPLOAD_DIR.$row['profile_image'];
		}

		return $sqlarray;
	}
}


 //http://infograins.com.208-91-199-7.md-plesk-web2.webhostbox.net/INFO01/orthodontist/api/api.php?action=UpdateAvatars&userid=5&default=default
function UserFeedback($data) {  
     $output = array();
    if ($data['username'] == NULL || $data['feedback'] == NULL || $data['driverid'] == NULL || $data['userid'] == NULL || $data['parcelid'] == NULL  ) 
    {
        $output['RESULT'] = "0";
        $output['msg'] = "userid should not be Empty";
        return $output;
    }
	else if($data['username']!='' || $data['feedback']!='' || $data['driverid']!='' || $data['userid']!='' || $data['parcelid']!='')
    {

		
				 $image = $_FILES['profileimage']['name'];
				 if($image!='')
				 {
				 $image= time().$image;  
						$uploadfile=UPLOAD_DIR_FEEDBACK.$image;
						move_uploaded_file($_FILES['profileimage']['tmp_name'],$uploadfile);
				 }
				 else
				 {
					$image='user.jpg'; 
				 }  
			date_default_timezone_set('Asia/Calcutta'); 
		$date=date('Y-m-d G:i:s');
		 $sql="insert into `user_driver_feedback` SET `driverid`='".$data['driverid']."' ,`username`='".$data['username']."',`profileimage`='$image',`feedback`='".$data['username']."' ,`date`='".$date."' ,`userid`='".$data['userid']."' ,`parcelid`='".$data['parcelid']."'";
		$sqlquery=mysql_query($sql);
		if($sqlquery)
		{
	    $output['success'] = "1";
		$output['msg'] = "successfully submitted feedback"; 
		
		return $output; 
		}
		else
		{
		 $output['success'] = "0";
		$output['msg'] = "error"; 
		return $output;	
		}
	
	}			
}
 
//get user profile
//https://infograins.com/INFO01/motoxpressapi/api.php?action=FeedbackList&driverid=1
function FeedbackList($data) {  
    $output = array();
    if ($data['driverid'] == NULL ) 
    {
        $output['success'] = "0";
        $output['msg'] = "driverid should not be Empty";
        return $output;
    }
    else if($data['driverid']!='')
    {
		$result1 = Getdriverfeedbackbyid($data['driverid']);
		 if ($result1>0) 
        {
            $output['success'] = "1";
            $output['msg'] = "successfully";
            $output['feedbacklist']=$result1;
			return $output; 
        }
        else 
        {
            $output['success'] = "0";
            $output['msg'] = "feedback no found";
            return $output; 
        }
    }
}     

 
 function Getdriverfeedbackbyid($userid) {
    $sql = "SELECT * FROM `user_driver_feedback` WHERE `driverid`='".$userid."'"; 
    $sqlquery1=mysql_query($sql);
	 $num=mysql_num_rows($sqlquery1);   
		if($num>0){
			$i=0;
		while ($row=mysql_fetch_array($sqlquery1))
		{			
		$sqlarray[$i]['feedbackid']=$row['id'];
	    $sqlarray[$i]['driverid']=$row['driverid'];
		 $sqlarray[$i]['username']=$row['username'];
    	$sqlarray[$i]['profileimage']=UPLOAD_DIR_FEEDBACK.$row['profileimage'];  
		$sqlarray[$i]['feedback']=$row['feedback'];  
		$sqlarray[$i]['date']=$row['date'];
	    
				$i++; 
								
		} 
		return $sqlarray;
	 }
	else
	{
		return '0';
	}	
}


// ge order hostory
// https://infograins.com/INFO01/tayar/API/api.php?action=History&delivery_status=1

function History($data)
{
	$output = array();
if ($data['did'] == NULL  )
	{ 
		$output['success'] = "0";
		$output['msg'] = "Check All Parameters";
		return $output;
	}
	else
	if ($data['did'] != '')
	{
		$result = gethistory($data['did'],$data['page']);
		if ($result ==0)
		{
			$output['success'] = "0";
			$output['msg'] = "History not available";
			return $output;
		}
		else
		{
			$output['success'] = "1";
			$output['msg'] = "successfully";
			$output['historlist'] = $result;
			return $output;
		}
	}
}

function gethistory($did,$page)
{
	$num_rec_per_page=10;
    $start_from = ($page) * $num_rec_per_page; 

	 $sql = "SELECT t . * , u . * FROM  `moto_parcle_orders` AS t INNER JOIN moto_users AS u ON t.`uid` = u.userid WHERE  `did` =  '$did' and delivery_status='completing' LIMIT $start_from, $num_rec_per_page ";
		
	$sqlquery = mysql_query($sql);
	$num = mysql_num_rows($sqlquery);
	if ($num > 0)
	{
		$i = 0;
		while ($row = mysql_fetch_array($sqlquery))
		{
			    $sqlarray[$i]['parcelid'] = $row['id'];
				$sqlarray[$i]['userfullname'] = $row['fullname'];
				$sqlarray[$i]['useremail'] = $row['email'];
				$sqlarray[$i]['usermobile'] = $row['mobile'];
				$sqlarray[$i]['userprofile_image'] = UPLOAD_DIR.$row['profile_image'];
				$user = runnerdetailsbyid($row['did']);
				if($user['username']=='')
				{
					$sqlarray[$i]['runnerfullname'] = '';
				}
				else
				{
				$sqlarray[$i]['runnerfullname'] = $user['username'];
				}
				if($user['email']=='')
				{
					$sqlarray[$i]['runneremail'] = '';
				}
				else
				{
				$sqlarray[$i]['runneremail'] = $user['email'];
				}
				if($user['mobile']=='')
				{
					$sqlarray[$i]['runnermobile'] = '';
				}
				else
				{
				$sqlarray[$i]['runnermobile']=$user['mobile'];
				}
				if($user['profile_image']=='')
				{
					$sqlarray[$i]['runnerprofile_image'] = '';
				}
				else
				{
				$sqlarray[$i]['runnerprofile_image'] =  RUNNER_IMG.$user['profile_image'];
				}
                $sqlarray[$i]['picupaddress']=$row['picupaddress'];
				$sqlarray[$i]['dropoffaddress']=$row['dropoffaddress'];
				$sqlarray[$i]['picupcontactname']=$row['picupcontactname'];
				$sqlarray[$i]['dropoffcontactname']=$row['dropoffcontactname'];
				$sqlarray[$i]['pickupunitnumber']=$row['pickupunitnumber'];
				$sqlarray[$i]['dropoffunitnumber']=$row['dropoffunitnumber'];
				$sqlarray[$i]['pickupcnatctnumber']=$row['pickupcnatctnumber'];
				$sqlarray[$i]['dropoffcontactnumber']=$row['dropoffcontactnumber'];
				$sqlarray[$i]['picupcompany']=$row['picupcompany'];
				$sqlarray[$i]['dropoffcompany']=$row['dropoffcompany'];
				$sqlarray[$i]['photo']=$row['photo'];
				$sqlarray[$i]['short_ins']=$row['short_ins'];
				$sqlarray[$i]['delivery_ins']=$row['delivery_ins'];
				$sqlarray[$i]['noti_email']=$row['noti_email'];
				$sqlarray[$i]['payment_method']=$row['payment_method'];
				$sqlarray[$i]['photo']=$row['photo'];
				$sqlarray[$i]['short_ins']=$row['short_ins'];
				$sqlarray[$i]['delivery_ins']=$row['delivery_ins'];
				$sqlarray[$i]['noti_email']=$row['noti_email'];
				$sqlarray[$i]['cdate']=$row['cdate'];
				$sqlarray[$i]['total_cost']=$row['total_cost'];
				$sqlarray[$i]['delivery_plan']=$row['delivery_plan'];
				$sqlarray[$i]['delivery_time']=$row['delivery_time'];
				$sqlarray[$i]['total_distance']=$row['total_distance'];
				$sqlarray[$i]['deliver_by']=$row['deliver_by'];
				$sqlarray[$i]['total_cost']=$row['total_cost'];
				$sqlarray[$i]['pic_at_time']=$row['pic_at_time'];
				$sqlarray[$i]['delivery_time']=$row['delivery_time'];
				$sqlarray[$i]['total_distance']=$row['total_distance'];
				$sqlarray[$i]['parcle_type']=$row['parcle_type'];
				$sqlarray[$i]['no_of_item']=$row['no_of_item'];
				$sqlarray[$i]['width']=$row['width'];
				$sqlarray[$i]['height']=$row['height'];
				$sqlarray[$i]['weight']=$row['weight'];
				$sqlarray[$i]['length']=$row['length'];
				$sqlarray[$i]['delivery_status']=$row['delivery_status'];
				$sqlarray[$i]['payment_status']=$row['payment_status'];
				$sqlarray[$i]['status']=$row['status'];
				$sqlarray[$i]['plat']=$row['plat'];
				$sqlarray[$i]['plong']=$row['plong'];
				$sqlarray[$i]['dlat']=$row['dlat'];
				$sqlarray[$i]['dlong']=$row['dlong'];
				$sqlarray[$i]['did']=$row['did'];
				 
			$i++;
		
		}
			return $sqlarray;
	}
	else
	{
		return '0';
	}
	}
	

	function NotificationList($data)
{
	$output = array();
	if ($data['userid'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else 
	{
	
		$sql = "SELECT * FROM `moto_parcel_notification` WHERE `uid` = '" . $data['userid'] . "' order by id desc";
        $sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			$i = 0;
			while ($row = mysql_fetch_array($sqlquery))
			{
				$sqlarray[$i]['id'] = $row['id'];
				$sqlarray[$i]['parcelid'] = $row['pid'];
				$sqlarray[$i]['userid'] = $row['uid'];
                $user_sql = "SELECT * FROM `moto_users` WHERE `userid` = '".$row['uid']."'";
                
				$user_res = mysql_query($user_sql);
				$user_row = mysql_fetch_assoc($user_res);
                $sqlarray[$i]['userfullname'] = $user_row['fullname'];
				$sqlarray[$i]['useremail'] = $user_row['email'];
				$sqlarray[$i]['usermobile'] = $user_row['mobile'];
				$sqlarray[$i]['userprofile_image'] = $user_row['profile_image'];
				
		
				$sqlarray[$i]['delivery_status'] = $row['delivery_status'];
				$parcel_sql = "SELECT * FROM `moto_parcle_orders` WHERE `id` = '".$row['pid']."'";
                
				$parcel_res = mysql_query($parcel_sql);
				$parcel_row = mysql_fetch_assoc($parcel_res);
		$user_sql = "SELECT * FROM `moto_runner` WHERE `rid` = '".$parcel_row['did']."'";
                
				$user_res = mysql_query($user_sql);
				$user_row = mysql_fetch_assoc($user_res);
                $sqlarray[$i]['runnerfullname'] = $user_row['username'];
				$sqlarray[$i]['runneremail'] = $user_row['email'];
				$sqlarray[$i]['runnermobile'] = $user_row['mobile'];
				$sqlarray[$i]['runnerprofile_image'] = RUNNER_IMG.$user_row['profile_image'];
                $sqlarray[$i]['picupaddress']=$parcel_row['picupaddress'];
				$sqlarray[$i]['dropoffaddress']=$parcel_row['dropoffaddress'];
				$sqlarray[$i]['picupcontactname']=$parcel_row['picupcontactname'];
				$sqlarray[$i]['dropoffcontactname']=$parcel_row['dropoffcontactname'];
				$sqlarray[$i]['pickupunitnumber']=$parcel_row['pickupunitnumber'];
				$sqlarray[$i]['dropoffunitnumber']=$parcel_row['dropoffunitnumber'];
				$sqlarray[$i]['pickupcnatctnumber']=$parcel_row['pickupcnatctnumber'];
				$sqlarray[$i]['dropoffcontactnumber']=$parcel_row['dropoffcontactnumber'];
				$sqlarray[$i]['picupcompany']=$parcel_row['picupcompany'];
				$sqlarray[$i]['dropoffcompany']=$parcel_row['dropoffcompany'];
				$sqlarray[$i]['photo']=$parcel_row['photo'];
				$sqlarray[$i]['short_ins']=$parcel_row['short_ins'];
				$sqlarray[$i]['delivery_ins']=$parcel_row['delivery_ins'];
				$sqlarray[$i]['noti_email']=$parcel_row['noti_email'];
				$sqlarray[$i]['payment_method']=$parcel_row['payment_method'];
				$sqlarray[$i]['photo']=$parcel_row['photo'];
				$sqlarray[$i]['short_ins']=$parcel_row['short_ins'];
				$sqlarray[$i]['delivery_ins']=$parcel_row['delivery_ins'];
				$sqlarray[$i]['noti_email']=$parcel_row['noti_email'];
				$sqlarray[$i]['cdate']=$parcel_row['cdate'];
				$sqlarray[$i]['total_cost']=$parcel_row['total_cost'];
				$sqlarray[$i]['delivery_plan']=$parcel_row['delivery_plan'];
				$sqlarray[$i]['delivery_time']=$parcel_row['delivery_time'];
				$sqlarray[$i]['total_distance']=$parcel_row['total_distance'];
				$sqlarray[$i]['deliver_by']=$parcel_row['deliver_by'];
				$sqlarray[$i]['total_cost']=$parcel_row['total_cost'];
				$sqlarray[$i]['pic_at_time']=$parcel_row['pic_at_time'];
				$sqlarray[$i]['delivery_time']=$parcel_row['delivery_time'];
				$sqlarray[$i]['total_distance']=$parcel_row['total_distance'];
				$sqlarray[$i]['parcle_type']=$parcel_row['parcle_type'];
				$sqlarray[$i]['no_of_item']=$parcel_row['no_of_item'];
				$sqlarray[$i]['width']=$parcel_row['width'];
				$sqlarray[$i]['height']=$parcel_row['height'];
				$sqlarray[$i]['weight']=$parcel_row['weight'];
				$sqlarray[$i]['length']=$parcel_row['length'];
				$sqlarray[$i]['delivery_status']=$parcel_row['delivery_status'];
				$sqlarray[$i]['payment_status']=$parcel_row['payment_status'];
				$sqlarray[$i]['status']=$parcel_row['status'];
				$sqlarray[$i]['plat']=$parcel_row['plat'];
				$sqlarray[$i]['plong']=$parcel_row['plong'];
				$sqlarray[$i]['dlat']=$parcel_row['dlat'];
				$sqlarray[$i]['dlong']=$parcel_row['dlong'];
				$sqlarray[$i]['notistatus'] = $row['status'];
				


				$i++;
			}

			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['Detail'] = $sqlarray;
			return $output;
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "No notification Found";
			return $output;
		}
	}
}
	
 function ParcelDriverStatus($data)
{
	$output = array();
	if($data['parcelid'] == NULL || $data['noti_id'] == NULL)
	{
		$output['success'] = 0;
		$output['msg'] = "Check Parameter";
		return $output;
	}
	else
	{
			$sql_status = "UPDATE `moto_parcel_notification` SET `status`='1' WHERE `id` = '" . $data['noti_id'] . "'";
        $sql_res_status = mysql_query($sql_status);
		$sql = "SELECT * FROM `moto_parcle_orders` WHERE `id` = '".$data['parcelid']."'";
		$sqlquery = mysql_query($sql);
		$num = mysql_num_rows($sqlquery);
		if ($num > 0)
		{
			
			while ($row = mysql_fetch_array($sqlquery))
			{
				$noti_sql = "SELECT * FROM `moto_parcle_orders` WHERE `id` = '".$data['parcelid']."'";
				$noti_sqlquery = mysql_query($noti_sql);
				$noti_res = mysql_fetch_array($noti_sqlquery); 
				$sqlarray['delivery_status'] = $noti_res['delivery_status'];
			    $sqlarray['driver'] = $row['picupcontactname'];
				$sqlarray['parcle_type'] = $row['parcle_type'];
				$sqlarray['status'] = $row['status'];
				
			}

			$output['success'] = "1";
			$output['msg'] = "Success";
			$output['Detail'] = $sqlarray;
			return $output;
		}
		else
		{
			$output['success'] = "0";
			$output['msg'] = "No Parcel id Found";
			return $output;
		}
	}
}
function sendnotificationuser($registatoin_ids, $message)
{
     $googleapikey = 'AIzaSyCePG0GQmDrVCdbZvVSNntRUYSIZO-BI18';
// Set POST variables 
       $url = 'https://android.googleapis.com/gcm/send';

       $fields = array(
           'registration_ids' => $registatoin_ids,
           'data' => $message
       );

       $headers = array(
           'Authorization: key=' . $googleapikey,
           'Content-Type: application/json'
       );
       // Open connection
       $ch = curl_init();   

       // Set the url, number of POST vars, POST data
       curl_setopt($ch, CURLOPT_URL, $url);

       curl_setopt($ch, CURLOPT_POST, true);
       curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

       // Disabling SSL Certificate support temporarly
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

       curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

       // Execute post
       $result = curl_exec($ch);
       if ($result === FALSE) {
           die('Curl failed: ' . curl_error($ch));
       }

       // Close connection
       curl_close($ch);
       return  $result;

}	


function sendnotificationiosOwner($deviceToken, $message) 
{
	$deviceToken=$deviceToken[0];
	$alert=$message['notification'];
	$messgaaa=$message['msg'];
	$type=$message['type'];
	$passphrase = '1234';
	/************************Start Push***************************/
	$ctx = stream_context_create();
	stream_context_set_option($ctx, 'ssl', 'local_cert', 'PemFile/User/MotoRunner_Developement.pem');
	stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
 
	// Open a connection to the APNS server
	$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
	if (!$fp)
		exit("Failed to connect: $err $errstr" . PHP_EOL);
	// Create the payload body
	$body['aps'] = array(
	            'content-available' => 1,
                'alert' => $alert,
				'badge' => 1, 
				'msg' => $messgaaa,
				'type' => $type,
				'sound' => 'oven.caf',
		);
	// Encode the payload as JSON
	$payload = json_encode($body);
	// Build the binary notification
	$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
	// Send it to the server
	$result = fwrite($fp, $msg, strlen($msg));
	// Close the connection to the server
	fclose($fp);
	if (!$result)
	{
		return '1';
	}  
	else
	{
		return '0'; 
	}
} 

function sendnotificationiosDriver($deviceToken, $message) 
{
	
	$deviceToken=$deviceToken[0];
	/* $alert=$message['notification'];
	$requestid=$message['requestid'];
	$messgaaa=$message['msg'];
	$type=$message['type'];
	$passphrase = '1234';
    $requestid=$message['requestid'];
	$userid=$message['userid'];
	$ownername=$message['ownername'];
	$mobileno=$message['mobileno'];
	$profileimage=$message['profileimage'];
	$pickuplocation=$message['pickuplocation'];
	$userlat=$message['userlat'];
	$userlong=$message['userlong'];
	$plat=$message['plat'];
	$plong=$message['plong'];
	$ordertype=$message['ordertype']; 
	$type=$message['type']; */
	 
	 
	/*******************Start Push*****************************/
	$ctx = stream_context_create();
	stream_context_set_option($ctx, 'ssl', 'local_cert', 'PemFile/Runner/MotoXRun_Dis.pem');
	stream_context_set_option($ctx, 'ssl', 'passphrase', '1234');
	// Open a connection to the APNS server
	$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
	if (!$fp) 
		exit("Failed to connect: $err $errstr" . PHP_EOL);
	// Create the payload body
	if($message['notitype']=='new_parcel')
	{
		$body['aps'] = array(
                'alert' => $message['notification'],
				'badge' => 1, 
				'sound' => 'oven.caf',
				'content-available'=>1,
		);
	    $body['newparcel'] = array(
              
				'msg' => $message['msg'],
				'notitype' => $message['notitype'],
				 
				 
		);
		//print_r($message);
	} 
		else if($message['notitype']=='demo')
	{
		$body['aps'] = array(
                'alert' => $message['notification'],
				'badge' => 1, 
				'sound' => 'oven.caf',
				'content-available'=>1,
		);
	    $body['userdata'] = array(
              
				'msg' => $message['msg'],
				'parcelid' => $message['parcelid'],
				'userid' => $message['userid'],
				'notitype' => $message['notitype'],
				 
				 
		);
		print_r($deviceToken);
	}
	
	// Encode the payload as JSON
	$payload = json_encode($body);
	// Build the binary notification
	$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
	// Send it to the server
	$result = fwrite($fp, $msg, strlen($msg));
	//print_r($result);
	// Close the connection to the server
	fclose($fp);
	if (!$result)
	{
		return '1';
	}  
	else
	{
		return '0'; 
	}
}




function sendnotificationiosUser($deviceToken, $message) 
{
	
	$deviceToken=$deviceToken[0];
	/* $alert=$message['notification'];
	$requestid=$message['requestid'];
	$messgaaa=$message['msg'];
	$type=$message['type'];
	$passphrase = '1234';
    $requestid=$message['requestid'];
	$userid=$message['userid'];
	$ownername=$message['ownername'];
	$mobileno=$message['mobileno'];
	$profileimage=$message['profileimage'];
	$pickuplocation=$message['pickuplocation'];
	$userlat=$message['userlat'];
	$userlong=$message['userlong'];
	$plat=$message['plat'];
	$plong=$message['plong'];
	$ordertype=$message['ordertype']; 
	$type=$message['type']; */
	 
	  
	/*******************Start Push*****************************/
	$ctx = stream_context_create();
	stream_context_set_option($ctx, 'ssl', 'local_cert', 'PemFile/User/MotoXUser_Adhoc.pem');
	stream_context_set_option($ctx, 'ssl', 'passphrase', '1234');
	// Open a connection to the APNS server
	$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
	if (!$fp)
		exit("Failed to connect: $err $errstr" . PHP_EOL);
	// Create the payload body
	if($message['notitype']=='acceptdriver')
	{
		$body['aps'] = array(
                'alert' => $message['notification'],
				'badge' => 1, 
				'sound' => 'oven.caf',
				'content-available'=>1,
		);
	    $body['userdata'] = array(
              
				'msg' => $message['msg'],
				'parcelid' => $message['parcelid'],
				'driverid' => $message['driverid'],
				'drivername' => $message['drivername'],
				'deli_status' => $message['delivery_status'],
				'notitype' => $message['notitype'],
				
				 
				
		);
	} 
	else if($message['notitype']=='deliverystatus')
	{
		$body['aps'] = array(
                'alert' => $message['notification'],
				'badge' => 1, 
				'sound' => 'oven.caf',
				'content-available'=>1,
		);
		$body['userdata'] = array(
               
				'msg' => $message['msg'],
				'parcelid' => $message['parcelid'],
				'driverid' => $message['driverid'],
				'drivername' => $message['drivername'],
				'deli_status' => $message['delivery_status'],
			'notitype' => $message['notitype'],
		);
	}
	else if($message['notitype']=='deliverycomplete')
	{
		$body['aps'] = array(
                'alert' => $message['notification'],
				'badge' => 1, 
				'sound' => 'oven.caf',
				'content-available'=>1,
		);
		$body['userdata'] = array(
               
				'msg' => $message['msg'],
				'parcelid' => $message['parcelid'],
				'driverid' => $message['driverid'],
				'drivername' => $message['drivername'],
				'deli_status' => $message['delivery_status'],
			  'notitype' => $message['notitype'],

		);
	}
		else if($message['notitype']=='demo')
	{
		$body['aps'] = array(
                'alert' => $message['notification'],
				'badge' => 1, 
				'sound' => 'oven.caf',
				'content-available'=>1,
		);
	    $body['userdata'] = array(
              
				'msg' => $message['msg'],
				'parcelid' => $message['parcelid'],
				'userid' => $message['userid'],
				'notitype' => $message['notitype'],
				 
				 
		);
		//print_r($message);
	} 
	// Encode the payload as JSON
	$payload = json_encode($body);
	// Build the binary notification
	$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
	// Send it to the server
	$result = fwrite($fp, $msg, strlen($msg));
	//print_r($result);
	// Close the connection to the server
	fclose($fp);
	if (!$result)
	{
		return '1';
	}  
	else
	{
		return '0'; 
	}
} 

 function sendMessage($data,$target){
	/*  
	Parameter Example
	$data = array('post_id'=>'12345','post_title'=>'A Blog post');
	$target = 'single tocken id or topic name';
	or
	$target = array('token1','token2','...'); // up to 1000 in one request
	*/
	
	//FCM api URL
	$url = 'https://fcm.googleapis.com/fcm/send';
	//api_key available in Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key
	$server_key = 'AIzaSyBOLdExfHrGbUFO7Y_8iimhoLjA9mAHSkk';
			
	$fields = array();
	$fields['data'] = $data;
	
	if(is_array($target)){
		$fields['registration_ids'] = $target;
		//print_r($fields['registration_ids']);
	}else{
		$fields['to'] = $target;
	}
	//header with content_type api key
	$headers = array(
		'Content-Type:application/json',
		'Authorization:key='.$server_key);
			
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
	$result = curl_exec($ch);
	if ($result === FALSE) {
		die('FCM Send Error: ' . curl_error($ch));
	}
	curl_close($ch);
	return $result;
}


function sendMessagedriver($data,$target){
	/*  
	Parameter Example
	$data = array('post_id'=>'12345','post_title'=>'A Blog post');
	$target = 'single tocken id or topic name';
	or
	$target = array('token1','token2','...'); // up to 1000 in one request
	*/
	
	//FCM api URL
	$url = 'https://fcm.googleapis.com/fcm/send';
	//api_key available in Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key
	$server_key = 'AIzaSyBGjoMtf_3pld_BA7fiE9qSu52nzQmcuKg';
			
	$fields = array();
	$fields['data'] = $data;
	
	if(is_array($target)){
		$fields['registration_ids'] = $target;
	}else{
		$fields['to'] = $target;
	}
	//header with content_type api key
	$headers = array(
		'Content-Type:application/json',
		'Authorization:key='.$server_key);
			
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
	$result = curl_exec($ch);
	if ($result === FALSE) {
		die('FCM Send Error: ' . curl_error($ch));
	}
	curl_close($ch);
	return $result;
}?>