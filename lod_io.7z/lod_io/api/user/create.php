<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// get database connection
include_once '../config/database.php';
 
// instantiate product object
include_once '../objects/user.php';
 
$database = new Database();
$db = $database->getConnection();
 
$user = new user($db);
 
// get posted data
//$data = json_decode(file_get_contents($_POST));
// print_r($data);
 //echo 'yes';
// var_dump($data);
 //die;
// make sure data is not empty
if (empty($_REQUEST['fullname']))
{
	 http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Check field Fullname."));
}
else if (empty($_REQUEST['email']))
{
	 http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Check field email."));
}
else if (!stristr($_REQUEST['email'],"@") OR !stristr($_REQUEST['email'],".")){ 
 http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Invalid Email."));
}
else if (empty($_REQUEST['password']))
{
	 http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Check field password."));
}
else if (strlen($_REQUEST['password']) <= '5') {
	http_response_code(400);
	echo json_encode(array("message" => "Your Password Must Contain At Least 6 Characters!"));
        
    }
else if (empty($_REQUEST['mobile']))
{ 
	 http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Check field mobile."));
}
else if(!preg_match('/^\d{10}$/',$_REQUEST['mobile'])){ // phone number is valid
    
     http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Mobile Invalid."));

      // your other code here
    
}
else if (empty($_REQUEST['user_type']))
{
	 http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Check field user_type."));
}
else if (empty($_REQUEST['device_id']))
{
	 http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Check field device_id."));
}
else if (empty($_REQUEST['device_type']))
{
	 http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Check field device_type."));
}
else if (empty($_REQUEST['status']))
{
	 http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Check field status."));
}

else if (!empty($_REQUEST['email']) || !empty($_REQUEST['mobile']))
{

	global $conn;
   $sql = "SELECT `email`,`mobile` FROM `lod_users` WHERE (email='".$_REQUEST['email']."' or mobile='".$_REQUEST['mobile']."')";
$result = mysqli_query($conn, $sql);
 $email = $_REQUEST['email'];
 $mobile = $_REQUEST['mobile'];
  if (mysqli_num_rows($result) > 0) {
            // output data of each row
            $row = mysqli_fetch_assoc($result);
			$ema = $row['email'];
			$mob = $row['mobile'];
            if ($email==$ema)
            {
                echo "Email already exists";
            }
            else if($mobile==$mob)
            {
                echo "Mobile already exists";
            }
        }
		else if(

    !empty($_REQUEST['fullname']) &&
    !empty($_REQUEST['email']) &&
    !empty($_REQUEST['mobile']) &&
    !empty($_REQUEST['user_type'])&&
    !empty($_REQUEST['device_id'])&&
    !empty($_REQUEST['device_type'])&&
    !empty($_REQUEST['status'])&&
    !empty($_REQUEST['password'])
){
 
    // set product property values
  $user->fullname = $_REQUEST['fullname'];
    $user->email = $_REQUEST['email'];
    $user->mobile = $_REQUEST['mobile'];
    $user->user_type = $_REQUEST['user_type'];
	$user->device_id = $_REQUEST['device_id'];
	$user->device_type = $_REQUEST['device_type'];
	$user->status = $_REQUEST['status'];
	$user->reg_time = date('Y-m-d H:i:s');
	$user->update_time = date('Y-m-d H:i:s');
	$user->password = $_REQUEST['password'];

 

 
    // create the product
    if($user->create()){
 
        // set response code - 201 created
        http_response_code(201);
 
        // tell the user
        echo json_encode(array("message" => "user was created."));
    }
 
    // if unable to create the product, tell the user
    else{
 
        // set response code - 503 service unavailable
        http_response_code(503);
 
        // tell the user
        echo json_encode(array("message" => "Unable to create user."));
    }
}
 
// tell the user data is incomplete
else{
 
    // set response code - 400 bad request
    http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Unable to create user. Parameter is incomplete."));
}
}

?>